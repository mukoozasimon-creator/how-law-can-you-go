---
title: "Marijuana Laws - Indiana"
state: "Indiana"
state_code: "IN"
topic: "Marijuana Laws"
tier: 1
date_created: "2026-08-26"
last_reviewed: "2026-08-26"
status: "active"
---

# Marijuana Laws - Indiana

## One-Sentence Verdict

Recreational marijuana remains fully illegal in Indiana; possession of any amount is a Class B misdemeanor punishable by up to 180 days in jail and a $1,000 fine, while the only legal cannabis is CBD oil with less than 0.3% THC for seizure disorders, and no medical marijuana program exists.

---

## Legal Status Summary

| Category | Status | Effective Date |
|----------|--------|----------------|
| Recreational (adult-use) | Illegal | N/A |
| Medical | Illegal (CBD oil only for seizures) | 2017 (SB 52) |
| Home cultivation | Illegal | N/A |
| Retail sales | Illegal | N/A |
| Decriminalization | No | N/A |

---

## Named Instruments

| Citation | Name | Live Link |
|----------|------|-----------|
| Ind. Code Sec. 35-48-4-11 | Possession of marijuana | [iga.in.gov](https://iga.in.gov) |
| Ind. Code Sec. 35-48-2-4 | Schedule I controlled substances | [iga.in.gov](https://iga.in.gov) |
| Ind. Code Sec. 35-48-4-10 | Dealing in marijuana | [iga.in.gov](https://iga.in.gov) |
| SB 52 (2017) | CBD oil exemption | [iga.in.gov](https://iga.in.gov) |
| SB 1045 (2026) | Proposed legalization bill | [iga.in.gov](https://iga.in.gov) |

---

## Verbatim Quotes Anchored to Character Offsets

### Ind. Code Sec. 35-48-4-11 - Possession

> "A person who: (1) knowingly or intentionally possesses (pure or adulterated) marijuana, hash oil, hashish, or salvia; ... commits possession of marijuana, hash oil, hashish, or salvia, a Class B misdemeanor."

- **Character offset**: beginning at "A person who: (1) knowingly or intentionally possesses" through "a Class B misdemeanor."
- **Source**: Indiana Code, Title 35, Article 48, Chapter 4, Section 35-48-4-11, current through 2026.
- **Live link**: [Indiana General Assembly](https://iga.in.gov)

### Ind. Code Sec. 35-48-4-11(b) - Enhanced Penalty

> "However, the offense is a Class A misdemeanor if the person has a prior conviction for a drug offense."

- **Character offset**: beginning at "However, the offense is a Class A misdemeanor" through "prior conviction for a drug offense."
- **Source**: Indiana Code, Section 35-48-4-11(b).
- **Live link**: [Indiana General Assembly](https://iga.in.gov)

---

## Repeal Check

| Item | Status | Date Checked |
|------|--------|--------------|
| Ind. Code Sec. 35-48-4-11 | Active | 2026-08-26 |
| SB 52 (CBD exemption) | Active | 2026-08-26 |
| SB 1045 (legalization) | Pending (not advanced) | 2026-08-26 |

No active legalization bill as of August 2026. SB 1045 was introduced but has not advanced.

---

## Possession Penalties

| Amount | Classification | Penalty |
|--------|-----------------|---------|
| Any amount (first offense) | Class B Misdemeanor | Up to 180 days jail, $1,000 fine |
| Any amount (prior drug conviction) | Class A Misdemeanor | Up to 1 year jail, $5,000 fine |
| 30g+ (with prior conviction) | Level 6 Felony | 6 months - 2.5 years, $10,000 fine |

### Concentrates

| Amount | Classification | Penalty |
|--------|-----------------|---------|
| Less than 5g | Class B Misdemeanor | Up to 180 days jail, $1,000 fine |
| 5g+ (with prior conviction) | Level 6 Felony | 6 months - 2.5 years, $10,000 fine |

### Sale/Cultivation

| Amount | Classification | Penalty |
|--------|-----------------|---------|
| Less than 30g | Class A Misdemeanor | Up to 1 year jail, $5,000 fine |
| 30g - less than 10 lbs | Level 6 Felony | 6 months - 2.5 years, $10,000 fine |
| 10+ lbs | Level 5 Felony | 1-6 years, $10,000 fine |

---

## Medical Program

- **Status**: NO comprehensive medical marijuana program exists in Indiana.
- **2017 CBD Oil Law (SB 52)**: Allows possession of CBD oil with less than 0.3% THC for patients with treatment-resistant epilepsy. This is NOT a true medical cannabis program.
- **No dispensaries**: There are no licensed medical cannabis dispensaries in Indiana.
- **No home cultivation**: Patients cannot grow their own medicine.
- **No reciprocity**: Out-of-state medical cards are NOT recognized.

---

## Hemp and CBD

- **Hemp-derived CBD**: Legal under federal Farm Bill; must contain 0.3% or less Delta-9 THC.
- **Delta-8, Delta-10**: In legal gray area; no explicit state ban as of August 2026.
- **Hemp vapes**: No explicit state ban.

---

## Local Decriminalization

- **No statewide decriminalization**: Indiana has no decriminalization at the state level.
- **Local ordinances**: Some municipalities have enacted civil penalties for small amounts, but these do not override state law. State police and other state law enforcement can still arrest under state statute.

---

## DUI / Impairment

- **Standard**: It is illegal to operate a motor vehicle while intoxicated by any drug (Ind. Code Sec. 9-30-5-1).
- **Per se limit**: No specific THC blood limit.
- **Penalties**: First offense - up to 60 days jail, $500 fine, license suspension up to 2 years.

---

## Employment Protections

- **No statutory protection**: Indiana does not protect off-duty cannabis use.
- **At-will employment**: Employers may terminate for cannabis use.
- **Federal contractors**: Subject to federal Drug-Free Workplace Act.

---

## Federal Conflict Notes

- **Schedule I federally**: All marijuana remains Schedule I under federal law.
- **Federal property**: Illegal on federal land and in federal buildings.
- **Federal housing**: Public housing may prohibit cannabis use.

---

## Distinctive State Features

1. **One of ~10 states with no medical program**: Indiana has no comprehensive medical cannabis program.
2. **First offense = criminal**: Even first-time possession is a criminal misdemeanor with potential jail time.
3. **No decriminalization**: Unlike neighboring Illinois, Michigan, and Ohio, Indiana has not decriminalized or legalized.
4. **Surrounded by legal states**: Indiana is bordered by Illinois, Michigan, and Ohio - all recreational-legal states - creating significant cross-border enforcement challenges.

---

## Cross-State Comparison Table

| Feature | Indiana | National Average |
|---------|---------|------------------|
| Recreational legal | No | ~24 states |
| Medical legal | No (CBD only) | ~38 states |
| Home cultivation | No | ~20 states |
| First offense penalty | Misdemeanor with jail | Varies |
| Employment protections | No | ~10 states |

---

## Recording Consent Rules

Indiana is a **one-party consent** state for audio recordings. Ind. Code Sec. 35-33.5-5 makes it a felony to record a private communication without the consent of at least one party.

---

## Practical Notes

- Even a single joint can result in arrest and jail time in Indiana.
- Do not bring cannabis from Illinois, Michigan, or Ohio into Indiana - this is a serious crime.
- If you have a medical card from another state, it is NOT recognized in Indiana.
- The only legal cannabis product is CBD oil with less than 0.3% THC for seizure disorders.
- Indiana State Police actively patrol borders with legal states.

---

## Related Entries

- [marijuana-laws-il.md](marijuana-laws-il.md) - Illinois (neighbor, recreational)
- [marijuana-laws-mi.md](marijuana-laws-mi.md) - Michigan (neighbor, recreational)
- [marijuana-laws-oh.md](marijuana-laws-oh.md) - Ohio (neighbor, recreational)
- [marijuana-laws-ky.md](marijuana-laws-ky.md) - Kentucky (neighbor, medical only)
- [tenant-rights-in.md](tenant-rights-in.md) - Indiana Tenant Rights

---

*Review date: 2026-08-26. This entry reflects statutes current as of that date. Always verify with current official sources before relying on this information.*
