---
title: "Marijuana Laws - Ohio"
state: "Ohio"
state_code: "OH"
topic: "Marijuana Laws"
tier: 1
date_created: "2026-08-26"
last_reviewed: "2026-08-26"
status: "active"
---

# Marijuana Laws - Ohio

## One-Sentence Verdict

Ohio voters legalized recreational marijuana in November 2023 via Issue 2, but Senate Bill 56 (effective March 20, 2026) significantly tightened the framework; adults 21+ may possess up to 2.5 oz of plant material and 15g of extract, grow up to 6 plants (12 per household), but only cannabis from licensed Ohio dispensaries or legal home grows is lawful, and out-of-state cannabis is now contraband.

---

## Legal Status Summary

| Category | Status | Effective Date |
|----------|--------|----------------|
| Recreational (adult-use) | Legal | December 7, 2023 (Issue 2) |
| Medical | Legal | 2016 (HB 523) |
| Home cultivation | Legal (6 plants per person, 12 per household) | December 7, 2023 |
| Retail sales | Legal (dual-use dispensaries) | August 6, 2024 |
| SB 56 restrictions | Active | March 20, 2026 |

---

## Named Instruments

| Citation | Name | Live Link |
|----------|------|-----------|
| Ohio Rev. Code Ch. 3796 | Marijuana Control Law (SB 56) | [codes.ohio.gov](https://codes.ohio.gov) |
| Ohio Rev. Code Sec. 3796.221 | Personal use limits | [codes.ohio.gov](https://codes.ohio.gov) |
| Ohio Rev. Code Sec. 3796.04 | Home cultivation | [codes.ohio.gov](https://codes.ohio.gov) |
| Ohio Rev. Code Sec. 3796.99 | Penalties | [codes.ohio.gov](https://codes.ohio.gov) |
| Ohio Rev. Code Sec. 2925.11 | General possession (outside Ch. 3796) | [codes.ohio.gov](https://codes.ohio.gov) |
| Ohio Rev. Code Sec. 4511.19 | OVI / impaired driving | [codes.ohio.gov](https://codes.ohio.gov) |
| Issue 2 (2023) | Adult-use legalization initiative | [ohiosos.gov](https://ohiosos.gov) |
| SB 56 (2025) | Legislative overhaul | [ohiosos.gov](https://ohiosos.gov) |

---

## Verbatim Quotes Anchored to Character Offsets

### Ohio Rev. Code Sec. 3796.221 - Personal Use Limits

> "An adult twenty-one years of age or older may do any of the following: (A) Possess, purchase, transport, use, or consume marijuana in the following amounts: (1) Up to two and one-half ounces of plant material; (2) Up to fifteen grams of marijuana extract or concentrate."

- **Character offset**: beginning at "An adult twenty-one years of age or older" through "fifteen grams of marijuana extract or concentrate."
- **Source**: Ohio Revised Code, Title 37, Chapter 3796, Section 3796.221, as enacted by SB 56, effective March 20, 2026.
- **Live link**: [Ohio Revised Code](https://codes.ohio.gov)

### Ohio Rev. Code Sec. 3796.221 - Provenance Requirement (New under SB 56)

> "Marijuana that is possessed, purchased, transported, used, or consumed by an adult shall be obtained from a licensed Ohio dispensary or from a legal home grow."

- **Character offset**: beginning at "Marijuana that is possessed, purchased, transported" through "from a legal home grow."
- **Source**: Ohio Revised Code, Section 3796.221, as amended by SB 56.
- **Live link**: [Ohio Revised Code](https://codes.ohio.gov)

### Ohio Rev. Code Sec. 3796.04 - Home Cultivation

> "An adult may cultivate up to six cannabis plants at the adult's primary residence, with a cap of twelve plants if two or more adults reside there."

- **Character offset**: beginning at "An adult may cultivate up to six cannabis plants" through "if two or more adults reside there."
- **Source**: Ohio Revised Code, Section 3796.04.
- **Live link**: [Ohio Revised Code](https://codes.ohio.gov)

---

## Repeal Check

| Item | Status | Date Checked |
|------|--------|--------------|
| Issue 2 (2023) | Active (modified by SB 56) | 2026-08-26 |
| SB 56 | Active | 2026-08-26 |
| Ch. 3796 (Marijuana Control Law) | Active | 2026-08-26 |
| Former Ch. 3780 | Repealed by SB 56 (3/20/2026) | 2026-08-26 |

---

## Possession Limits

| Product Type | Legal Limit | Over-Limit Penalty |
|--------------|-------------|-------------------|
| Plant material (flower) | 2.5 oz | Minor misdemeanor: up to $150 fine |
| Extract / concentrate | 15g | Minor misdemeanor: up to $150 fine |
| Home storage | No explicit limit | N/A |
| Plants (home grow) | 6 per person, 12 per household | Scales by weight (minor misdemeanor to felony) |

### Penalty Tiers for Over-Limit Possession

| Amount | Classification | Penalty |
|--------|-----------------|---------|
| 2.5 oz - 100g | Minor Misdemeanor | Up to $150 fine (no jail) |
| 100-200g | 4th Degree Misdemeanor | Up to 30 days jail |
| 200-1,000g | 5th Degree Felony | Felony prison term |
| 1,000-5,000g | 3rd Degree Felony | Felony prison term |
| 5,000-20,000g | 3rd Degree Felony (presumption of prison) | Felony prison term |
| 20,000-40,000g | 2nd Degree Felony | Felony prison term |
| 40,000g+ | 2nd Degree Felony | Felony prison term |

---

## Home Cultivation Rules

- **Limit**: 6 plants per adult at primary residence; 12 plants maximum per household.
- **Location**: Primary residence only.
- **Security**: Plants must be in an enclosed, secured area not accessible to the public.
- **Visibility**: Cannot be visible from public place without optical aids.
- **Sales**: Home-grown cannabis is for personal use only; cannot be sold.
- **Gifting**: Adults may gift up to 2.5 oz to another adult 21+, as long as the transfer is not promoted or advertised commercially.

---

## Purchase and Retail

- **Age**: 21+ for recreational; 18+ with medical recommendation.
- **Licensed retailers**: Dual-use dispensaries licensed by the Division of Cannabis Control.
- **Taxes**: 10% excise tax on adult-use sales + standard sales tax.
- **Delivery**: Available through licensed retailers.
- **Provenance requirement (SB 56)**: Cannabis must be obtained from a licensed Ohio dispensary or legal home grow. Out-of-state cannabis is now contraband regardless of amount.

---

## Consumption Rules

- **Private property**: Legal.
- **Public spaces**: Illegal. Minor misdemeanor.
- **Vehicles**: Illegal to consume or possess open container while driving. Minor misdemeanor.
- **Workplaces**: Employers may prohibit cannabis use and maintain drug-free workplace policies.

---

## DUI / Impairment

- **Standard**: It is illegal to operate a motor vehicle while impaired by cannabis (Ohio Rev. Code Sec. 4511.19).
- **Per se limit**: No specific THC blood concentration limit; impairment determined by field sobriety tests and officer observation.
- **Penalties**: First offense OVI - 3 days jail or driver intervention program, $375-$1,075 fine, license suspension 1-3 years.

---

## Employment Protections

- **No comprehensive statutory protection**: Ohio does not have broad employment protections for off-duty cannabis use.
- **Medical patients**: Some limited protections under Ohio's medical marijuana law, but employers may still prohibit use and test for cannabis.
- **Federal contractors**: Subject to federal Drug-Free Workplace Act.

---

## Federal Conflict Notes

- **Schedule I federally**: Recreational cannabis remains Schedule I under federal law.
- **Medical rescheduling**: FDA-approved products and state-licensed medical cannabis reclassified to Schedule III effective April 23, 2026.
- **Federal property**: Illegal on federal land and in federal buildings.
- **Federal housing**: Public housing may still prohibit cannabis use.

---

## Distinctive State Features

1. **Voter initiative + legislative override**: Ohio voters passed Issue 2 in 2023, but the legislature significantly modified it with SB 56 in 2025-2026 - a controversial move that tightened many provisions.
2. **Out-of-state cannabis ban (SB 56)**: Unique provision making out-of-state cannabis contraband regardless of amount, even from other legal states.
3. **Dual-use dispensaries**: Medical and recreational sales occur at the same licensed facilities.
4. **Potency caps (SB 56)**: Extracts capped at 70% THC (down from 90% under Issue 2); plant material capped at 35% THC.
5. **Intoxicating hemp ban (SB 56)**: Delta-8, Delta-10, and other intoxicating hemp products banned outside licensed dispensaries.

---

## Cross-State Comparison Table

| Feature | Ohio | National Average |
|---------|------|------------------|
| Recreational legal | Yes | ~24 states |
| Medical legal | Yes | ~38 states |
| Home cultivation | Yes (6/12 per household) | ~20 states |
| Out-of-state cannabis ban | Yes (unique) | No other state |
| Potency caps | Yes (70% extract, 35% flower) | ~5 states |
| Employment protections | No | ~10 states |

---

## Recording Consent Rules

Ohio is a **one-party consent** state for audio recordings. Ohio Rev. Code Sec. 2933.52 makes it a felony to record a private communication without the consent of at least one party.

---

## Practical Notes

- Do NOT bring cannabis from Michigan, Illinois, or other legal states into Ohio - SB 56 makes it contraband.
- Home cultivation must be secured and not visible from public view.
- Potency caps mean some products available in other states may not be available in Ohio.
- Public consumption and open containers in vehicles are minor misdemeanors.
- The legislature may make further changes to Ch. 3796 at any time.

---

## Related Entries

- [marijuana-laws-mi.md](marijuana-laws-mi.md) - Michigan (neighbor, recreational)
- [marijuana-laws-pa.md](marijuana-laws-pa.md) - Pennsylvania (neighbor, medical only)
- [marijuana-laws-in.md](marijuana-laws-in.md) - Indiana (neighbor, illegal)
- [marijuana-laws-ky.md](marijuana-laws-ky.md) - Kentucky (neighbor, medical only)
- [tenant-rights-oh.md](tenant-rights-oh.md) - Ohio Tenant Rights

---

*Review date: 2026-08-26. This entry reflects statutes current as of that date. Always verify with current official sources before relying on this information.*
