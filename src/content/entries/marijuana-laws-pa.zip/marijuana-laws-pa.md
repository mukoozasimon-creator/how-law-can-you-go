---
title: "Marijuana Laws - Pennsylvania"
state: "Pennsylvania"
state_code: "PA"
topic: "Marijuana Laws"
tier: 1
date_created: "2026-08-26"
last_reviewed: "2026-08-26"
status: "active"
---

# Marijuana Laws - Pennsylvania

## One-Sentence Verdict

Pennsylvania permits medical marijuana for registered patients with 24 qualifying conditions but recreational marijuana remains illegal; possession of 30g or less is a misdemeanor punishable by up to 30 days in jail and a $500 fine, while Philadelphia and Pittsburgh have enacted local decriminalization ordinances.

---

## Legal Status Summary

| Category | Status | Effective Date |
|----------|--------|----------------|
| Recreational (adult-use) | Illegal | N/A |
| Medical | Legal | April 17, 2016 (Act 16 / SB 3) |
| Home cultivation | Illegal (even for medical patients) | N/A |
| Retail sales | Medical only (licensed dispensaries) | 2018 |
| Smoking medical cannabis | Prohibited | Ongoing |

---

## Named Instruments

| Citation | Name | Live Link |
|----------|------|-----------|
| 35 P.S. Sec. 10231.101 et seq. | Medical Marijuana Act (Act 16) | [pacodeandbulletin.gov](https://pacodeandbulletin.gov) |
| 35 P.S. Sec. 780-113 | Possession of controlled substance | [pacodeandbulletin.gov](https://pacodeandbulletin.gov) |
| 35 P.S. Sec. 780-113.1 | Possession of small amount | [pacodeandbulletin.gov](https://pacodeandbulletin.gov) |
| HB 1200 (2025) | Adult-use legalization (passed House, died in Senate) | [palegis.us](https://palegis.us) |

---

## Verbatim Quotes Anchored to Character Offsets

### 35 P.S. Sec. 780-113.1 - Possession of Small Amount

> "A person commits a misdemeanor of the third degree if he possesses a small amount of marijuana only for his personal use. For purposes of this subsection, thirty grams of marijuana or eight grams of hashish shall be considered a small amount."

- **Character offset**: beginning at "A person commits a misdemeanor" through "shall be considered a small amount."
- **Source**: Pennsylvania Statutes, Title 35, Section 780-113.1, current through 2026.
- **Live link**: [PA General Assembly](https://palegis.us)

### Act 16 - Medical Marijuana Program

> "The department shall establish a medical marijuana program to provide access to medical marijuana to patients with a serious medical condition through a safe and effective method of delivery that balances patient need for access with the need to maintain strict regulation."

- **Character offset**: beginning at "The department shall establish" through "maintain strict regulation."
- **Source**: Pennsylvania Medical Marijuana Act, 35 P.S. Sec. 10231.101 et seq.
- **Live link**: [PA Department of Health](https://health.pa.gov)

---

## Repeal Check

| Item | Status | Date Checked |
|------|--------|--------------|
| Act 16 (Medical) | Active | 2026-08-26 |
| 35 P.S. Sec. 780-113.1 | Active | 2026-08-26 |
| HB 1200 (legalization) | Died in Senate (2025) | 2026-08-26 |

No active recreational legalization bill as of August 2026. Governor Shapiro has included legalization in his last three budget proposals.

---

## Possession Penalties (Recreational)

| Amount | Classification | Penalty |
|--------|-----------------|---------|
| 30g or less (flower) / 8g or less (hashish) | Misdemeanor 3rd Degree | Up to 30 days jail, $500 fine |
| More than 30g | Misdemeanor 1st Degree | Up to 1 year jail, $5,000 fine |
| 2nd or subsequent offense | Enhanced | Up to 3 years, $25,000 fine |

### Cultivation

| Activity | Classification | Penalty |
|----------|-----------------|---------|
| Growing any amount | Felony | 2.5-5 years prison, $15,000 fine |

### Concentrates

| Activity | Classification | Penalty |
|----------|-----------------|---------|
| Possession of any amount | Felony | Varies by weight |

---

## Medical Program

- **Program name**: Pennsylvania Medical Marijuana Program (administered by PA Department of Health).
- **Qualifying conditions**: 24 conditions including cancer, epilepsy, glaucoma, HIV/AIDS, PTSD, ALS, Crohn's, Parkinson's, MS, chronic pain, opioid use disorder, anxiety disorders, and terminal illness.
- **Product types**: Oils, tinctures, capsules, topicals, vaporization products. **Smoking is PROHIBITED** even for medical patients.
- **Possession limit**: 90-day supply as determined by dispensary pharmacist; up to 30-day supply per purchase.
- **Registration**: Patient must be a PA resident, obtain certification from a registered physician, and receive a PA MMJ ID card.
- **No reciprocity**: Out-of-state medical cards are NOT recognized.
- **No home cultivation**: Patients cannot grow their own medicine.
- **Age**: 18+; minors may participate through registered caregivers.

---

## Local Decriminalization

- **Philadelphia**: City ordinance imposes $25 civil fine for possession of 30g or less.
- **Pittsburgh**: Decriminalized small amounts with civil fine.
- **Other cities**: Harrisburg, York, Lancaster, Bethlehem, and others have similar ordinances.
- **Important**: Local decriminalization does NOT override state law. State police and other state law enforcement can still arrest under state statute.

---

## DUI / Impairment

- **Standard**: Pennsylvania has a **zero-tolerance** law for THC in blood while driving (75 Pa.C.S. Sec. 3802(d)).
- **Medical card NOT a defense**: Having a medical marijuana card does NOT protect against DUI charges.
- **THC metabolites**: Can remain detectable in blood for days or weeks after use.
- **Penalties**: First offense - up to 6 months probation, $300 fine, license suspension; enhanced penalties for repeat offenses and injuries.

---

## Employment Protections

- **No statutory protection**: Pennsylvania does not protect off-duty cannabis use, including medical use.
- **At-will employment**: Employers may terminate for cannabis use.
- **Federal contractors**: Subject to federal Drug-Free Workplace Act.
- **Medical patients**: No employment protections under Act 16.

---

## Federal Conflict Notes

- **Schedule I federally**: All marijuana remains Schedule I under federal law.
- **Medical rescheduling**: Limited to FDA-approved products and state-licensed medical programs.
- **Federal property**: Illegal on federal land and in federal buildings.
- **Federal housing**: Public housing may prohibit medical marijuana use.

---

## Distinctive State Features

1. **No smoking medical cannabis**: Pennsylvania is one of the few medical states that explicitly prohibits smoking, even for registered patients. Vaporization is permitted.
2. **Zero-tolerance DUI**: One of the strictest DUI laws for cannabis users - any detectable THC metabolite can trigger a DUI charge.
3. **No home cultivation**: Even medical patients cannot grow their own medicine.
4. **House passed legalization**: HB 1200 passed the PA House in May 2025 - the first time a legalization bill passed either chamber - but died in the Senate.
5. **Local decriminalization patchwork**: Multiple cities have decriminalized, creating inconsistent enforcement across the state.

---

## Cross-State Comparison Table

| Feature | Pennsylvania | National Average |
|---------|--------------|------------------|
| Recreational legal | No | ~24 states |
| Medical legal | Yes | ~38 states |
| Home cultivation | No | ~20 states |
| Smoking medical flower | No | ~30 states |
| Zero-tolerance DUI | Yes | ~15 states |
| Employment protections | No | ~10 states |

---

## Recording Consent Rules

Pennsylvania is a **two-party consent** state for audio recordings. 18 Pa.C.S. Sec. 5703 makes it a felony to record a private communication without the consent of all parties.

---

## Practical Notes

- Even small amounts of recreational marijuana can result in criminal charges in most of Pennsylvania.
- If you have a medical card from another state, it is NOT valid in Pennsylvania.
- Medical patients must use vaporization, oils, tinctures, or capsules - smoking is illegal even with a card.
- Do NOT drive after using cannabis - Pennsylvania's zero-tolerance DUI law applies to medical patients too.
- Philadelphia and Pittsburgh have civil fines, but state police can still arrest.

---

## Related Entries

- [marijuana-laws-ny.md](marijuana-laws-ny.md) - New York (neighbor, recreational)
- [marijuana-laws-nj.md](marijuana-laws-nj.md) - New Jersey (neighbor, recreational)
- [marijuana-laws-oh.md](marijuana-laws-oh.md) - Ohio (neighbor, recreational)
- [marijuana-laws-wv.md](marijuana-laws-wv.md) - West Virginia (neighbor, medical)
- [tenant-rights-pa.md](tenant-rights-pa.md) - Pennsylvania Tenant Rights

---

*Review date: 2026-08-26. This entry reflects statutes current as of that date. Always verify with current official sources before relying on this information.*
