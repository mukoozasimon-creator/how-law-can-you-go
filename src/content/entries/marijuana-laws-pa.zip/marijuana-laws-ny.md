---
title: "Marijuana Laws - New York"
state: "New York"
state_code: "NY"
topic: "Marijuana Laws"
tier: 1
date_created: "2026-08-26"
last_reviewed: "2026-08-26"
status: "active"
---

# Marijuana Laws - New York

## One-Sentence Verdict

New York legalized recreational marijuana for adults 21+ in March 2021 via the Marijuana Regulation and Taxation Act (MRTA); adults may possess up to 3 oz of flower and 24g of concentrate in public, store up to 5 lbs at home, and cultivate up to 6 plants per person (12 per household), with employment protections for off-duty use.

---

## Legal Status Summary

| Category | Status | Effective Date |
|----------|--------|----------------|
| Recreational (adult-use) | Legal | March 31, 2021 |
| Medical | Legal | 2014 (Compassionate Care Act) |
| Home cultivation | Legal (6 plants per person, 12 per household) | 2023+ |
| Retail sales | Legal (licensed dispensaries) | December 2022 |
| Social consumption | Legal (licensed on-site consumption) | 2023 |

---

## Named Instruments

| Citation | Name | Live Link |
|----------|------|-----------|
| Cannabis Law Art. 1-22 (MRTA) | Marijuana Regulation and Taxation Act | [cannabis.ny.gov](https://cannabis.ny.gov) |
| NY Pub. Health Law Art. 33 | Medical cannabis program | [health.ny.gov](https://health.ny.gov) |
| NY Labor Law Sec. 201-d | Off-duty lawful activities | [dol.ny.gov](https://dol.ny.gov) |
| NY Penal Law Sec. 221.05 | Unlawful possession | [nysenate.gov](https://nysenate.gov) |

---

## Verbatim Quotes Anchored to Character Offsets

### MRTA - Possession Limits

> "A person twenty-one years of age or older may lawfully possess, use, transport, obtain or give away without compensation up to three ounces of cannabis and up to twenty-four grams of concentrated cannabis."

- **Character offset**: beginning at "A person twenty-one years of age or older" through "twenty-four grams of concentrated cannabis."
- **Source**: New York Cannabis Law, Article 2, Section 2, as enacted by MRTA (S.854-A/A.1248-A), March 31, 2021.
- **Live link**: [New York Cannabis Office](https://cannabis.ny.gov)

### MRTA - Home Cultivation

> "A person twenty-one years of age or older may cultivate up to three mature cannabis plants and three immature cannabis plants at any one time; provided, however, that no more than six mature cannabis plants and six immature cannabis plants may be cultivated in a private residence at any given time."

- **Character offset**: beginning at "A person twenty-one years of age or older" through "at any given time."
- **Source**: New York Cannabis Law, Article 2, Section 4, as enacted by MRTA.
- **Live link**: [New York Cannabis Office](https://cannabis.ny.gov)

### NY Labor Law Sec. 201-d - Employment Protections

> "It shall be unlawful for an employer to refuse to hire, employ or license, or to discharge from employment or otherwise discriminate against an individual in compensation, promotion or terms, conditions or privileges of employment because of: ... the individual's legal use of consumable products, including cannabis, prior to the beginning or after the conclusion of the employee's work hours, and off of the employer's premises and without use of the employer's equipment or other property."

- **Character offset**: beginning at "It shall be unlawful for an employer" through "employer's equipment or other property."
- **Source**: New York Labor Law, Article 7, Section 201-d, as amended by MRTA.
- **Live link**: [NYSenate.gov](https://nysenate.gov)

---

## Repeal Check

| Item | Status | Date Checked |
|------|--------|--------------|
| MRTA | Active | 2026-08-26 |
| NY Labor Law Sec. 201-d | Active | 2026-08-26 |
| Home cultivation rules | Active | 2026-08-26 |

No pending repeal legislation identified as of August 2026.

---

## Possession Limits

| Product Type | Public Limit | Home Storage Limit | Over-Limit Penalty |
|--------------|-------------|-------------------|-------------------|
| Cannabis flower | 3 oz (85g) | 5 lbs (2,268g) | Violation: fine up to $200 |
| Concentrated cannabis | 24g | 5 lbs equivalent | Violation: fine up to $200 |
| Plants (home grow) | 3 mature + 3 immature per person | 6 mature + 6 immature per household | Misdemeanor: up to 1 year jail, $1,000 fine |

### Penalty Tiers for Over-Limit Possession

| Amount | Classification | Penalty |
|--------|-----------------|---------|
| 3-8 oz | Violation | Fine up to $200 |
| 8 oz - 1 lb | Misdemeanor | Up to 1 year jail, $1,000 fine |
| 1-5 lbs | Felony (E) | Up to 4 years prison, $5,000 fine |
| 5-10 lbs | Felony (D) | Up to 7 years prison, $5,000 fine |
| 10+ lbs | Felony (C) | Up to 15 years prison, $15,000 fine |

---

## Home Cultivation Rules

- **Limit**: 3 mature + 3 immature plants per person; 6 mature + 6 immature per household maximum.
- **Location**: Private residence only (owned or rented). Landlords may prohibit only if they risk losing federal benefits.
- **Visibility**: Must be in a secure location not visible to the public.
- **Access**: Must be secured from persons under 21.
- **Sales**: Home-grown cannabis CANNOT be sold, traded, or bartered.
- **Local regulation**: Municipalities may reasonably regulate personal cultivation; violations are infractions with civil penalties up to $200. Municipalities may prohibit retail dispensaries but NOT personal cultivation.

---

## Purchase and Retail

- **Age**: 21+ for recreational; 18+ with medical certification.
- **Licensed retailers**: Office of Cannabis Management (OCM) licenses required.
- **Taxes**: 9% state excise tax + 4% local excise tax + standard sales tax.
- **Delivery**: Legal through licensed retailers.
- **Social equity**: 50% of licenses reserved for social equity applicants (justice-involved individuals, minority/women-owned businesses, distressed farmers).

---

## Consumption Rules

- **Private property**: Legal where tobacco smoking is permitted.
- **Public spaces**: Treated similarly to tobacco; generally permitted where tobacco smoking is allowed, but local ordinances may impose additional restrictions.
- **Enclosed public places**: Illegal (follows Clean Indoor Air Act).
- **Vehicles**: Illegal to consume or possess open container while driving.
- **Workplaces**: Employers may prohibit on-premises use and impairment but cannot discriminate for off-duty, off-premises use.

---

## DUI / Impairment

- **Standard**: It is illegal to operate a motor vehicle while impaired by cannabis (Vehicle & Traffic Law Sec. 1192).
- **Per se limit**: No specific THC blood concentration limit.
- **Drug Recognition Experts (DREs)**: Police use DREs and field sobriety tests to establish impairment.
- **Penalties**: Similar to alcohol DWI - license suspension, fines, jail time for repeat offenses.

---

## Employment Protections

- **Strong statutory protection**: NY Labor Law Sec. 201-d, as amended by MRTA, prohibits employers from discriminating against employees for lawful off-duty, off-premises cannabis use.
- **Exceptions**: Employers MAY take action if:
  - Employee is impaired at work.
  - Employer is required to take action by federal or state law/regulation.
  - Employee is in a safety-sensitive position.
  - Employer would lose federal contract or funding.
- **Drug testing**: Pre-employment and random testing for cannabis is generally prohibited unless required by federal law.

---

## Federal Conflict Notes

- **Schedule I federally**: Recreational cannabis remains Schedule I under federal law.
- **Medical rescheduling**: FDA-approved products and state-licensed medical cannabis reclassified to Schedule III effective April 23, 2026.
- **Federal property**: Illegal on federal land, including national parks and military installations.
- **Federal housing**: Public housing may still prohibit cannabis use.

---

## Distinctive State Features

1. **Strongest employment protections**: New York has among the strongest statutory employment protections for cannabis users in the nation.
2. **Social equity focus**: 50% of licenses reserved for social equity applicants.
3. **Automatic expungement**: MRTA provides for automatic expungement of prior marijuana convictions that would now be legal.
4. **Home cultivation with local limits**: Municipalities can regulate but not ban personal cultivation.
5. **Cannabis Control Board**: OCM oversees both medical and adult-use programs.

---

## Cross-State Comparison Table

| Feature | New York | National Average |
|---------|----------|------------------|
| Recreational legal | Yes | ~24 states |
| Medical legal | Yes | ~38 states |
| Home cultivation | Yes (6/12 per household) | ~20 states |
| Employment protections | Strong | ~10 states |
| Social equity program | Yes (50% licenses) | ~15 states |
| Automatic expungement | Yes | ~12 states |

---

## Recording Consent Rules

New York is a **one-party consent** state for audio recordings. NY Penal Law Sec. 250.00 et seq. makes it a crime to record a private communication without the consent of at least one party.

---

## Practical Notes

- Keep cannabis in original packaging when transporting.
- Do not consume in vehicles or while driving.
- Employers generally cannot fire you for off-duty use, but they CAN fire you for being impaired at work.
- Home cultivation must be secured from minors and not visible from public spaces.
- Municipalities can opt out of retail dispensaries but NOT personal cultivation.

---

## Related Entries

- [marijuana-laws-nj.md](marijuana-laws-nj.md) - New Jersey (neighbor, recreational)
- [marijuana-laws-ct.md](marijuana-laws-ct.md) - Connecticut (neighbor, recreational)
- [marijuana-laws-pa.md](marijuana-laws-pa.md) - Pennsylvania (neighbor, medical only)
- [tenant-rights-ny.md](tenant-rights-ny.md) - New York Tenant Rights

---

*Review date: 2026-08-26. This entry reflects statutes current as of that date. Always verify with current official sources before relying on this information.*
