---
title: "Marijuana Laws - North Carolina"
state: "North Carolina"
state_code: "NC"
topic: "Marijuana Laws"
tier: 1
date_created: "2026-08-26"
last_reviewed: "2026-08-26"
status: "active"
---

# Marijuana Laws - North Carolina

## One-Sentence Verdict

Marijuana remains fully illegal in North Carolina for both recreational and medical use; possession of 0.5 oz or less is a Class 3 misdemeanor with a maximum $200 fine and suspended jail sentence, while the only legal cannabis is sold on tribal sovereign land at the Eastern Band of Cherokee Indians' Great Smoky Cannabis Company, and the Compassionate Care Act has repeatedly stalled in the legislature.

---

## Legal Status Summary

| Category | Status | Effective Date |
|----------|--------|----------------|
| Recreational (adult-use) | Illegal | N/A |
| Medical | Illegal (no comprehensive program) | N/A |
| Home cultivation | Illegal | N/A |
| Retail sales | Illegal (except tribal sovereign land) | N/A |
| Decriminalization | Partial (0.5 oz or less = Class 3 misdemeanor) | Ongoing |

---

## Named Instruments

| Citation | Name | Live Link |
|----------|------|-----------|
| N.C. Gen. Stat. Sec. 90-95 | Controlled Substances Act | [ncleg.gov](https://ncleg.gov) |
| N.C. Gen. Stat. Sec. 90-95(a)(2) | Cultivation | [ncleg.gov](https://ncleg.gov) |
| N.C. Gen. Stat. Sec. 90-95(h) | Trafficking | [ncleg.gov](https://ncleg.gov) |
| N.C. Gen. Stat. Sec. 90-94(1)(d) | Schedule VI (marijuana) | [ncleg.gov](https://ncleg.gov) |
| 2014 Epilepsy Alternative Treatment Act | Limited hemp extract for epilepsy | [ncleg.gov](https://ncleg.gov) |
| Compassionate Care Act | Proposed medical marijuana (repeatedly stalled) | [ncleg.gov](https://ncleg.gov) |

---

## Verbatim Quotes Anchored to Character Offsets

### N.C. Gen. Stat. Sec. 90-95(d)(4) - Possession of Marijuana

> "Except as provided in this subsection, any person who violates this subsection with respect to: ... a controlled substance classified in Schedule VI, shall be guilty of a Class 3 misdemeanor and if the quantity of the controlled substance: a. Does not exceed one-half of an ounce (1/2 oz) by weight, the person shall be guilty of a Class 3 misdemeanor."

- **Character offset**: beginning at "Except as provided in this subsection" through "guilty of a Class 3 misdemeanor."
- **Source**: North Carolina General Statutes, Chapter 90, Article 5, Section 90-95, current through 2026.
- **Live link**: [NC General Assembly](https://ncleg.gov)

### N.C. Gen. Stat. Sec. 90-95(h) - Trafficking

> "Any person who sells, manufactures, delivers, transports, or possesses 10 pounds (10 lbs.) or more of marijuana shall be guilty of a felony which felony shall be known as 'trafficking in marijuana'."

- **Character offset**: beginning at "Any person who sells, manufactures, delivers" through "'trafficking in marijuana'."
- **Source**: North Carolina General Statutes, Section 90-95(h).
- **Live link**: [NC General Assembly](https://ncleg.gov)

---

## Repeal Check

| Item | Status | Date Checked |
|------|--------|--------------|
| N.C. Gen. Stat. Sec. 90-95 | Active | 2026-08-26 |
| Compassionate Care Act | Stalled in House (multiple sessions) | 2026-08-26 |
| Advisory Council on Cannabis | Recommendations only (EO 16, June 2025) | 2026-08-26 |

No active medical or recreational legalization bill as of August 2026. The Compassionate Care Act has passed the Senate multiple times but stalled in the House.

---

## Possession Penalties

| Amount | Classification | Penalty |
|--------|-----------------|---------|
| 0.5 oz or less | Class 3 Misdemeanor | Maximum $200 fine; jail suspended |
| 0.5 oz - 1.5 oz | Class 1 Misdemeanor | Up to 45 days jail, discretionary fine up to $1,000 |
| 1.5 oz - 10 lbs | Class I Felony | 3-8 months imprisonment, discretionary fine |

### Cultivation Penalties

| Amount | Classification | Penalty |
|--------|-----------------|---------|
| Less than 10 lbs | Class I Felony | 3-8 months imprisonment |
| 10-50 lbs | Class H Felony | 5-6 months imprisonment |
| 50-2,000 lbs | Class G Felony | 8-14 months imprisonment |
| 2,000-10,000 lbs | Class F Felony | 10-20 months imprisonment |
| 10,000+ lbs | Class D Felony | 35-51 months imprisonment |

### Trafficking Thresholds (Mandatory Minimums)

| Amount | Mandatory Minimum | Fine |
|--------|-------------------|------|
| 10-50 lbs | 25 months | $5,000 |
| 50-2,000 lbs | 35 months | $15,000 |
| 2,000-10,000 lbs | 70 months | $50,000 |
| 10,000+ lbs | 175 months | $200,000 |

### Concentrates (Hash, Wax, Vape Cartridges)

- **Any amount over 1/20th of an ounce** of marijuana resin extract (hash, wax, dabs, shatter, vape cartridges) is a **Class I felony**.
- This is an extremely low threshold - a single vape cartridge can trigger felony charges.

---

## Medical Program

- **Status**: NO comprehensive medical marijuana program exists in North Carolina.
- **2014 Epilepsy Alternative Treatment Act**: Very narrow exception for intractable epilepsy patients to possess hemp extracts with less than 0.9% THC and at least 5% CBD. This is NOT a true medical cannabis program.
- **Compassionate Care Act**: Has passed the NC Senate multiple times but repeatedly stalled in the House. As of August 2026, no medical program exists.
- **Governor's Advisory Council**: Created by Executive Order 16 (June 2025); approved interim report April 2, 2026. Recommendations carry no legal force.

---

## Tribal Exception

- **Eastern Band of Cherokee Indians (EBCI)**: Under tribal sovereignty, the EBCI has enacted its own cannabis laws independent of North Carolina state law.
- **Great Smoky Cannabis Company**: Opened in 2024 on the Qualla Boundary; first tribally-owned cannabis dispensary in North Carolina.
- **Adult-use sales**: Any adult 21+ with valid government-issued ID can purchase; no medical card required.
- **Important**: Tribal land is sovereign. State law does not apply. However, transporting cannabis OFF tribal land into North Carolina is illegal under state law.

---

## Hemp and CBD

- **Hemp-derived CBD**: Legal under federal Farm Bill; must contain 0.3% or less Delta-9 THC.
- **Hemp flower**: Looks and smells like marijuana; law enforcement may have difficulty distinguishing. Field tests can return positive even for legal hemp.
- **Delta-8, Delta-10**: In legal gray area; no explicit state ban as of August 2026.

---

## DUI / Impairment

- **Standard**: It is illegal to operate a motor vehicle while impaired by any substance (N.C. Gen. Stat. Sec. 20-138.1).
- **Per se limit**: No specific THC blood limit.
- **Penalties**: First offense - up to 60 days jail, $200 fine, license suspension 1 year.

---

## Employment Protections

- **No statutory protection**: North Carolina does not protect off-duty cannabis use.
- **At-will employment**: Employers may terminate for cannabis use.
- **Federal contractors**: Subject to federal Drug-Free Workplace Act.

---

## Federal Conflict Notes

- **Schedule I federally**: All marijuana remains Schedule I under federal law.
- **Federal property**: Illegal on federal land, including national parks (Great Smoky Mountains, Outer Banks, etc.).
- **Federal housing**: Public housing may prohibit cannabis use.

---

## Distinctive State Features

1. **One of 10 states with no medical or recreational program**: North Carolina is one of roughly 10 states with no comprehensive cannabis program.
2. **Extremely low concentrate felony threshold**: 1/20th of an ounce of resin extract triggers a Class I felony - one of the lowest thresholds in the nation.
3. **Tribal exception**: The EBCI's Great Smoky Cannabis Company is the only legal adult-use cannabis retailer in the state, operating under tribal sovereignty.
4. **Compassionate Care Act stalled**: Despite passing the Senate multiple times, the House has refused to advance medical cannabis legislation.
5. **Mandatory minimums for trafficking**: Harsh mandatory minimum prison sentences for 10+ lbs.

---

## Cross-State Comparison Table

| Feature | North Carolina | National Average |
|---------|----------------|------------------|
| Recreational legal | No | ~24 states |
| Medical legal | No (narrow epilepsy exception only) | ~38 states |
| Home cultivation | No | ~20 states |
| Concentrate felony threshold | 1/20 oz (extremely low) | Varies |
| Tribal adult-use sales | Yes | ~3 states |
| Employment protections | No | ~10 states |

---

## Recording Consent Rules

North Carolina is a **one-party consent** state for audio recordings. N.C. Gen. Stat. Sec. 15A-287 makes it a felony to record a private communication without the consent of at least one party.

---

## Practical Notes

- North Carolina has some of the harshest marijuana laws in the nation for concentrates.
- A single THC vape cartridge can result in a felony charge.
- The EBCI dispensary on tribal land is legal, but taking cannabis off tribal land is a state crime.
- Even small amounts of flower (0.5 oz or less) can result in criminal charges, though jail is typically suspended.
- Do not assume hemp/CBD products will protect you from arrest - field tests cannot distinguish hemp from marijuana.

---

## Related Entries

- [marijuana-laws-va.md](marijuana-laws-va.md) - Virginia (neighbor, recreational)
- [marijuana-laws-sc.md](marijuana-laws-sc.md) - South Carolina (neighbor, limited medical)
- [marijuana-laws-ga.md](marijuana-laws-ga.md) - Georgia (neighbor, limited medical)
- [marijuana-laws-tn.md](marijuana-laws-tn.md) - Tennessee (neighbor, limited medical)
- [tenant-rights-nc.md](tenant-rights-nc.md) - North Carolina Tenant Rights

---

*Review date: 2026-08-26. This entry reflects statutes current as of that date. Always verify with current official sources before relying on this information.*
