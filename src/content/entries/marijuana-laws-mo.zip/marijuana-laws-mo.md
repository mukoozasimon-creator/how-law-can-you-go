---
title: "Marijuana Laws - Missouri"
state: "Missouri"
state_code: "MO"
topic: "Marijuana Laws"
tier: 1
date_created: "2026-08-26"
last_reviewed: "2026-08-26"
status: "active"
---

# Marijuana Laws - Missouri

## One-Sentence Verdict

Missouri legalized recreational marijuana for adults 21+ in December 2022 via Amendment 3; adults may possess up to 3 oz of dried flower and grow up to 6 flowering plants, 6 non-flowering plants, and 6 clones per person (18 total), with a 6% state tax and automatic expungement for prior low-level convictions.

---

## Legal Status Summary

| Category | Status | Effective Date |
|----------|--------|----------------|
| Recreational (adult-use) | Legal | December 8, 2022 |
| Medical | Legal | 2018 (Amendment 2) |
| Home cultivation | Legal (6 flowering + 6 non-flowering + 6 clones per person) | December 8, 2022 |
| Retail sales | Legal (licensed dispensaries) | February 2023 |
| Automatic expungement | Yes | 2023 |

---

## Named Instruments

| Citation | Name | Live Link |
|----------|------|-----------|
| Mo. Rev. Stat. Sec. 195.010 et seq. | Article XIV - Marijuana (Amendment 3) | [revisor.mo.gov](https://revisor.mo.gov) |
| Mo. Rev. Stat. Sec. 195.805 | Personal use of marijuana | [revisor.mo.gov](https://revisor.mo.gov) |
| Mo. Rev. Stat. Sec. 195.817 | Home cultivation | [revisor.mo.gov](https://revisor.mo.gov) |
| Mo. Rev. Stat. Sec. 610.140 | Expungement | [revisor.mo.gov](https://revisor.mo.gov) |
| Amendment 3 (2022) | Adult-use legalization | [sos.mo.gov](https://sos.mo.gov) |

---

## Verbatim Quotes Anchored to Character Offsets

### Mo. Rev. Stat. Sec. 195.805 - Possession Limits

> "A person twenty-one years of age or older shall not be subject to arrest, prosecution, penalty, or civil liability for: (1) Possessing, purchasing, or obtaining three ounces or less of dried, unprocessed marijuana, or its equivalent;"

- **Character offset**: beginning at "A person twenty-one years of age or older" through "or its equivalent;"
- **Source**: Missouri Revised Statutes, Title XII, Chapter 195, Section 195.805, current through 2026.
- **Live link**: [Missouri Revisor of Statutes](https://revisor.mo.gov)

### Mo. Rev. Stat. Sec. 195.817 - Home Cultivation

> "A person twenty-one years of age or older may cultivate marijuana plants for personal use at a private residence, if the person: (1) Cultivates no more than six flowering marijuana plants, six nonflowering marijuana plants, and six clones at any given time;"

- **Character offset**: beginning at "A person twenty-one years of age or older" through "at any given time;"
- **Source**: Missouri Revised Statutes, Section 195.817.
- **Live link**: [Missouri Revisor of Statutes](https://revisor.mo.gov)

---

## Repeal Check

| Item | Status | Date Checked |
|------|--------|--------------|
| Amendment 3 | Active | 2026-08-26 |
| Mo. Rev. Stat. Sec. 195.805 | Active | 2026-08-26 |
| Mo. Rev. Stat. Sec. 195.817 | Active | 2026-08-26 |

No pending repeal legislation identified as of August 2026.

---

## Possession Limits

| Product Type | Legal Limit | Over-Limit Penalty |
|--------------|-------------|-------------------|
| Dried flower | 3 oz | Misdemeanor: up to 1 year jail, $2,000 fine |
| Concentrate | Part of 3 oz equivalent | Misdemeanor: up to 1 year jail, $2,000 fine |
| Plants (home grow) | 6 flowering + 6 non-flowering + 6 clones per person | Misdemeanor |

### Penalty Tiers for Over-Limit Possession

| Amount | Classification | Penalty |
|--------|-----------------|---------|
| 3 oz - 10 oz | Misdemeanor | Up to 1 year jail, $2,000 fine |
| 10 oz - 35 oz | Class E Felony | Up to 4 years prison |
| 35+ oz | Class D Felony | Up to 7 years prison |

---

## Home Cultivation Rules

- **Limit**: 6 flowering + 6 non-flowering + 6 clones per person. No household cap is specified.
- **Location**: Private residence only.
- **Security**: Must be in an enclosed, locked facility.
- **Visibility**: Cannot be visible from public view without optical aids.
- **Medical patients**: Same limits as recreational users.
- **Sales**: Home-grown cannabis is for personal use only; cannot be sold.
- **Gifting**: Adults may gift up to 3 oz to another adult 21+.

---

## Purchase and Retail

- **Age**: 21+ for recreational; 18+ with medical card.
- **Licensed retailers**: Missouri Department of Health and Senior Services (DHSS) licenses required.
- **Taxes**: 6% state tax + local taxes up to 3%.
- **Medical exemption**: Medical cannabis purchases are taxed at 4%.
- **Delivery**: Available through licensed retailers.

---

## Consumption Rules

- **Private property**: Legal.
- **Public spaces**: Illegal.
- **Vehicles**: Illegal to consume or possess open container while driving.
- **Workplaces**: Employers may prohibit cannabis use and maintain drug-free workplace policies.

---

## DUI / Impairment

- **Standard**: It is illegal to operate a motor vehicle while under the influence of marijuana (Mo. Rev. Stat. Sec. 577.010).
- **Per se limit**: No specific THC blood concentration limit.
- **Penalties**: First offense DWI - up to 6 months jail, $500 fine, license suspension 30 days-1 year.

---

## Employment Protections

- **No comprehensive statutory protection**: Missouri does not have broad employment protections for off-duty recreational cannabis use.
- **Medical patients**: Some protections under Amendment 2, but employers may still prohibit use in safety-sensitive positions.
- **Federal contractors**: Subject to federal Drug-Free Workplace Act.

---

## Federal Conflict Notes

- **Schedule I federally**: Recreational cannabis remains Schedule I under federal law.
- **Federal property**: Illegal on federal land and in federal buildings.

---

## Distinctive State Features

1. **Generous plant limits**: 18 plants per person (6 flowering + 6 non-flowering + 6 clones) is among the most generous in the nation.
2. **Automatic expungement**: Amendment 3 included automatic expungement for prior low-level marijuana convictions.
3. **Microbusiness licenses**: Missouri created a microbusiness licensing program to promote diversity in the industry.
4. **Low tax rate**: 6% state tax is among the lowest in recreational-legal states.

---

## Cross-State Comparison Table

| Feature | Missouri | National Average |
|---------|----------|------------------|
| Recreational legal | Yes | ~24 states |
| Medical legal | Yes | ~38 states |
| Home cultivation | Yes (18 plants/person) | ~20 states |
| Automatic expungement | Yes | ~12 states |
| Tax rate | 6% (low) | ~10-25% |
| Employment protections | Limited | ~10 states |

---

## Recording Consent Rules

Missouri is a **one-party consent** state for audio recordings. Mo. Rev. Stat. Sec. 542.402 makes it a crime to record a private communication without the consent of at least one party.

---

## Practical Notes

- Missouri has among the most generous home cultivation limits in the nation.
- Keep cannabis in original packaging when transporting.
- Do not consume in public or in vehicles.
- Prior low-level convictions may be eligible for automatic expungement.
- Employers can still test and terminate for cannabis use, even if legal.

---

## Related Entries

- [marijuana-laws-il.md](marijuana-laws-il.md) - Illinois (neighbor, recreational)
- [marijuana-laws-ks.md](marijuana-laws-ks.md) - Kansas (neighbor, illegal)
- [marijuana-laws-ok.md](marijuana-laws-ok.md) - Oklahoma (neighbor, medical only)
- [tenant-rights-mo.md](tenant-rights-mo.md) - Missouri Tenant Rights

---

*Review date: 2026-08-26. This entry reflects statutes current as of that date. Always verify with current official sources before relying on this information.*
