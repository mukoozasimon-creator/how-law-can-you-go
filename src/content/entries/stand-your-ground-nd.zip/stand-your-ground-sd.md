---
title: "Stand Your Ground / Self-Defense Rights - South Dakota"
state: "South Dakota"
state_code: "SD"
topic: "Stand Your Ground / Self-Defense"
tier: 1
date_created: "2026-08-26"
last_reviewed: "2026-08-26"
status: "active"
---

# Stand Your Ground / Self-Defense Rights - South Dakota

## One-Sentence Verdict

South Dakota is a statutory stand-your-ground state with "may stand his or her ground" language: a person who uses or threatens to use deadly force in accordance with the self-defense statute has no duty to retreat and has the right to stand their ground if they are not engaged in criminal activity and are in a place where they have a right to be.

---

## Named Instruments

| Citation | Name | Live Link |
|----------|------|-----------|
| SDCL 22-18-4 | Justifiable homicide - Use of force in defense of a person | [sdlegislature.gov](https://sdlegislature.gov/Statutes/22-18-4) |
| SDCL 22-18-4.1 | No duty to retreat | [sdlegislature.gov](https://sdlegislature.gov/Statutes/22-18-4.1) |
| SDCL 22-18-4.2 | Presumption of reasonableness in dwelling or residence | [sdlegislature.gov](https://sdlegislature.gov/Statutes/22-18-4.2) |
| SDCL 22-18-4.8 | Immunity from criminal prosecution and civil liability | [sdlegislature.gov](https://sdlegislature.gov/Statutes/22-18-4.8) |

---

## Verbatim Quotes Anchored to Character Offsets

### SDCL 22-18-4.1 - No Duty to Retreat

> "A person who uses or threatens to use deadly force in accordance with this section does not have a duty to retreat and has the right to stand his or her ground, if the person is not engaged in a criminal activity and is in a place where the person has a right to be."

- **Character offset**: beginning at "A person who uses or threatens to use deadly force" through "has a right to be."
- **Source**: South Dakota Codified Laws, Title 22, Chapter 18, Section 22-18-4.1, current through 2026.
- **Live link**: [SDCL](https://sdlegislature.gov/Statutes/22-18-4.1)

### SDCL 22-18-4.2 - Presumption of Reasonableness in Dwelling

> "A person who is in a dwelling or residence, in which the person has a right to be: (1) Has no duty to retreat; (2) Has the right to stand his or her ground; and (3) Is presumed to have acted reasonably in using or threatening to use deadly force if the person knew or had reason to believe that an unlawful entry into the dwelling or residence was occurring or had occurred."

- **Character offset**: beginning at "A person who is in a dwelling or residence" through "had occurred."
- **Source**: South Dakota Codified Laws, Title 22, Chapter 18, Section 22-18-4.2.
- **Live link**: [SDCL](https://sdlegislature.gov/Statutes/22-18-4.2)

### SDCL 22-18-4.8 - Immunity from Criminal Prosecution and Civil Liability

> "A person who uses or threatens to use force in accordance with Sec. 22-18-4, 22-18-4.1, or 22-18-4.2 is immune from criminal prosecution and civil action for the use or threatened use of such force by the person, unless the person against whom force was used or threatened is a law enforcement officer acting in the performance of the officer's official duties."

- **Character offset**: beginning at "A person who uses or threatens to use force" through "official duties."
- **Source**: South Dakota Codified Laws, Title 22, Chapter 18, Section 22-18-4.8.
- **Live link**: [SDCL](https://sdlegislature.gov/Statutes/22-18-4.8)

---

## Repeal Check

| Item | Status | Date Checked |
|------|--------|--------------|
| SDCL 22-18-4 | Active | 2026-08-26 |
| SDCL 22-18-4.1 | Active | 2026-08-26 |
| SDCL 22-18-4.2 | Active | 2026-08-26 |
| SDCL 22-18-4.8 | Active | 2026-08-26 |

No pending repeal legislation identified as of August 2026.

---

## Duty-to-Retreat Matrix

| Location | Duty to Retreat? | Statutory Basis |
|----------|------------------|-----------------|
| Own home / dwelling | No | SDCL 22-18-4.2(1) - "Has no duty to retreat" |
| Residence | No | SDCL 22-18-4.2 - explicit protection |
| Vehicle | No | SDCL 22-18-4.1 - "in a place where the person has a right to be" |
| Workplace | No | SDCL 22-18-4.1 - "in a place where the person has a right to be" |
| Public place (lawfully present) | No | SDCL 22-18-4.1 - "in a place where the person has a right to be" |

---

## Castle Doctrine Scope

- **Dwelling / Residence**: Full Castle Doctrine with statutory presumption of reasonableness under SDCL 22-18-4.2. The presumption applies if the person "knew or had reason to believe that an unlawful entry ... was occurring or had occurred."
- **Vehicle**: Covered under general SYG provision.
- **Workplace**: Covered under general SYG provision.
- **Curtilage**: Not explicitly defined, but "residence" may be interpreted broadly.

---

## Distinctive State Features

1. **"May Stand His or Her Ground" Language**: South Dakota is one of only eleven states that include the explicit "may stand his or her ground" language in statute, per NCSL tracking.
2. **Strongest SYG Language in the US**: According to NRA state director Brian Gosch, South Dakota has "the strongest stand your ground language in the United States." This is due to the combination of no-duty-to-retreat, presumption of reasonableness, and immunity provisions.
3. **Dual Immunity**: SDCL 22-18-4.8 provides immunity from both criminal prosecution AND civil liability - a powerful combination.
4. **Presumption in Dwelling**: The statutory presumption of reasonableness in SDCL 22-18-4.2 shifts the burden to the prosecution to disprove reasonableness.
5. **Law Enforcement Exception**: The immunity in 22-18-4.8 explicitly does not apply if the person against whom force was used is a law enforcement officer acting in official duties.

---

## Cross-State Comparison Table

| Feature | South Dakota | National Average |
|---------|--------------|------------------|
| Statutory SYG | Yes | ~38 states |
| "May stand his or her ground" language | Yes | ~11 states |
| No duty to retreat - public | Yes | ~38 states |
| No duty to retreat - home | Yes | All 50 states |
| Presumption of reasonableness in home | Yes | ~25 states |
| Civil immunity statute | Yes | ~15 states |
| Criminal immunity statute | Yes | ~10 states |
| Initial aggressor exception | Yes | All states |

---

## Recording Consent Rules

South Dakota is a **one-party consent** state for audio recordings. SDCL 22-24B-2 makes it a misdemeanor to record a private communication without the consent of at least one party.

---

## Practical Notes

- South Dakota's SYG law is among the strongest in the nation due to the combination of explicit "stand your ground" language, presumption of reasonableness, and dual criminal/civil immunity.
- The immunity provision (22-18-4.8) means that a person who uses force in accordance with the statute cannot be sued by the attacker or their estate for damages.
- The presumption of reasonableness in the dwelling (22-18-4.2) is rebuttable but places a significant burden on the prosecution.
- South Dakota has constitutional carry (no permit required for concealed carry) as of 2019, making SYG knowledge particularly important.
- The law enforcement exception in 22-18-4.8 is critical - using force against an officer, even in self-defense, may not be protected.

---

## Related Entries

- [stand-your-ground-nd.md](stand-your-ground-nd.md) - North Dakota (neighbor, SYG since 2021)
- [stand-your-ground-ne.md](stand-your-ground-ne.md) - Nebraska (neighbor, duty to retreat)
- [stand-your-ground-mn.md](stand-your-ground-mn.md) - Minnesota (neighbor, duty to retreat)
- [tenant-rights-sd.md](tenant-rights-sd.md) - South Dakota Tenant Rights

---

*Review date: 2026-08-26. This entry reflects statutes current as of that date. Always verify with current official sources before relying on this information.*
