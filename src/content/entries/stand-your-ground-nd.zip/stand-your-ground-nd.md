---
title: "Stand Your Ground / Self-Defense Rights - North Dakota"
state: "North Dakota"
state_code: "ND"
topic: "Stand Your Ground / Self-Defense"
tier: 1
date_created: "2026-08-26"
last_reviewed: "2026-08-26"
status: "active"
---

# Stand Your Ground / Self-Defense Rights - North Dakota

## One-Sentence Verdict

North Dakota became a statutory stand-your-ground state in 2021: a person who is not engaged in illegal activity and is in a place where they have a right to be has no duty to retreat before using force, including deadly force, if they reasonably believe it is necessary to prevent imminent death or serious bodily injury.

---

## Named Instruments

| Citation | Name | Live Link |
|----------|------|-----------|
| N.D. Cent. Code Sec. 12.1-05-07 | Justifiable use of force - No duty to retreat | [ndlegis.gov](https://www.ndlegis.gov/assembly/67-2021/documents/21-0361-02000.pdf) |
| N.D. Cent. Code Sec. 12.1-05-03 | Self-defense | [ndlegis.gov](https://www.ndlegis.gov) |

---

## Verbatim Quotes Anchored to Character Offsets

### N.D. Cent. Code Sec. 12.1-05-07 - No Duty to Retreat

> "An individual who is not engaged in an unlawful activity and who is in a place where the individual has a right to be has no duty to retreat before using or threatening to use force that is likely to cause death or serious bodily injury if the individual reasonably believes the use or threatened use of such force is necessary to prevent imminent death or serious bodily injury to the individual or another individual."

- **Character offset**: beginning at "An individual who is not engaged in an unlawful activity" through "another individual."
- **Source**: North Dakota Century Code, Title 12.1, Chapter 12.1-05, Section 12.1-05-07, enacted 2021, current through 2026.
- **Live link**: [North Dakota Century Code](https://www.ndlegis.gov)
- **Note**: Enacted by 2021 ND Laws, Ch. 116 (HB 1293), signed by Governor Doug Burgum on April 20, 2021.

---

## Repeal Check

| Item | Status | Date Checked |
|------|--------|--------------|
| N.D. Cent. Code Sec. 12.1-05-07 | Active | 2026-08-26 |
| N.D. Cent. Code Sec. 12.1-05-03 | Active | 2026-08-26 |

No pending repeal legislation identified as of August 2026.

---

## Duty-to-Retreat Matrix

| Location | Duty to Retreat? | Statutory Basis |
|----------|------------------|-----------------|
| Own home / dwelling | No | N.D. Cent. Code Sec. 12.1-05-07 - "in a place where the individual has a right to be" |
| Vehicle | No | N.D. Cent. Code Sec. 12.1-05-07 - "in a place where the individual has a right to be" |
| Workplace | No | N.D. Cent. Code Sec. 12.1-05-07 - "in a place where the individual has a right to be" |
| Public place (lawfully present) | No | N.D. Cent. Code Sec. 12.1-05-07 - "in a place where the individual has a right to be" |

---

## Castle Doctrine Scope

- **Home / Dwelling**: Full protection under the general SYG statute. Prior to 2021, North Dakota had a more limited "castle law" that only applied inside the home.
- **Vehicle**: Covered under the 2021 SYG expansion.
- **Workplace**: Covered under the 2021 SYG expansion.
- **Curtilage**: Not explicitly defined in statute.

---

## Distinctive State Features

1. **Most Recent SYG State**: North Dakota enacted its SYG law in 2021, making it one of the most recent states to adopt stand-your-ground protections. Governor Doug Burgum called it "the most consequential gun law change in North Dakota for a long time."
2. **Expanded from Castle Law**: Prior to 2021, North Dakota had a limited castle doctrine that only removed the duty to retreat inside the home. The 2021 law expanded this to any place where the person has a right to be.
3. **No Explicit Immunity**: Unlike South Dakota and some other SYG states, North Dakota's statute does not include explicit criminal or civil immunity provisions.
4. **Constitutional Carry**: North Dakota has constitutional carry (permitless carry) for residents, making SYG knowledge particularly relevant.
5. **Reasonable Belief Standard**: The statute requires that the individual "reasonably believes" the force is necessary - a subjective/objective standard that will be evaluated by courts.

---

## Cross-State Comparison Table

| Feature | North Dakota | National Average |
|---------|--------------|------------------|
| Statutory SYG | Yes (since 2021) | ~38 states |
| No duty to retreat - public | Yes | ~38 states |
| No duty to retreat - home | Yes | All 50 states |
| Presumption of fear in home | No explicit presumption | ~25 states |
| Civil immunity statute | No | ~15 states |
| Criminal immunity statute | No | ~10 states |
| Initial aggressor exception | Yes | All states |

---

## Recording Consent Rules

North Dakota is a **one-party consent** state for audio recordings. N.D. Cent. Code Sec. 12.1-15-02 makes it a misdemeanor to record a private communication without the consent of at least one party.

---

## Practical Notes

- North Dakota's SYG law is relatively new (2021), meaning there is limited case law interpreting its scope. Courts have not yet had many opportunities to define the boundaries of the statute.
- The lack of explicit immunity provisions means that while there is no duty to retreat, a person who uses force may still face criminal charges and civil lawsuits. The SYG provision is an affirmative defense to be raised at trial.
- The "reasonable belief" standard is critical. The defender's belief must be both honest and reasonable under the circumstances.
- North Dakota has constitutional carry, but non-residents still need a permit to carry concealed.
- Given the newness of the law, anyone involved in a use-of-force incident should seek experienced criminal defense counsel immediately.

---

## Related Entries

- [stand-your-ground-sd.md](stand-your-ground-sd.md) - South Dakota (neighbor, SYG with dual immunity)
- [stand-your-ground-mn.md](stand-your-ground-mn.md) - Minnesota (neighbor, duty to retreat)
- [stand-your-ground-mt.md](stand-your-ground-mt.md) - Montana (neighbor, SYG)
- [tenant-rights-nd.md](tenant-rights-nd.md) - North Dakota Tenant Rights

---

*Review date: 2026-08-26. This entry reflects statutes current as of that date. Always verify with current official sources before relying on this information.*
