---
title: "Marijuana Laws - New Jersey"
state: "New Jersey"
state_code: "NJ"
topic: "Marijuana Laws"
tier: 1
date_created: "2026-08-26"
last_reviewed: "2026-08-26"
status: "active"
---

# Marijuana Laws - New Jersey

## One-Sentence Verdict

New Jersey legalized recreational marijuana for adults 21+ in April 2022 via the CREAMM Act; adults may possess up to 6 oz of cannabis and purchase from licensed dispensaries, but home cultivation remains illegal for both recreational and medical users - one of only a handful of legal states with this prohibition.

---

## Legal Status Summary

| Category | Status | Effective Date |
|----------|--------|----------------|
| Recreational (adult-use) | Legal | April 21, 2022 |
| Medical | Legal | 2010 (Compassionate Use Medical Marijuana Act) |
| Home cultivation | Illegal (even for medical patients) | N/A |
| Retail sales | Legal (licensed dispensaries) | April 2022 |
| Public consumption | Illegal | Ongoing |

---

## Named Instruments

| Citation | Name | Live Link |
|----------|------|-----------|
| N.J.S.A. 24:6I-31 et seq. | Cannabis Regulatory, Enforcement Assistance, and Marketplace Modernization Act (CREAMM Act) | [njleg.state.nj.us](https://njleg.state.nj.us) |
| N.J.S.A. 24:6I-2 et seq. | Jake Honig Compassionate Use Medical Cannabis Act | [njleg.state.nj.us](https://njleg.state.nj.us) |
| N.J.S.A. 2C:35-10 | Possession of controlled dangerous substances | [njleg.state.nj.us](https://njleg.state.nj.us) |
| S2564 (2026-2027) | Proposed adult-use home cultivation bill | [njleg.state.nj.us](https://njleg.state.nj.us) |
| A1674/S1758 (2026-2027) | Proposed medical home cultivation bills | [njleg.state.nj.us](https://njleg.state.nj.us) |

---

## Verbatim Quotes Anchored to Character Offsets

### CREAMM Act - Possession Limits

> "A person 21 years of age or older may lawfully possess up to six ounces of cannabis."

- **Character offset**: standalone provision within the CREAMM Act framework.
- **Source**: New Jersey Statutes Annotated, Title 24, Chapter 6I, Section 24:6I-31 et seq., current through 2026.
- **Live link**: [New Jersey Legislature](https://njleg.state.nj.us)

### NJ-CRC FAQ - Home Cultivation Prohibition

> "No. Current New Jersey law does not give authority to NJ-CRC to authorize private, residential, or any growing of cannabis outside of a business with a cultivation license."

- **Character offset**: beginning at "No. Current New Jersey law" through "cultivation license."
- **Source**: New Jersey Cannabis Regulatory Commission, General Information FAQ, current through 2026.
- **Live link**: [NJ Cannabis Regulatory Commission](https://www.nj.gov/cannabis)

---

## Repeal Check

| Item | Status | Date Checked |
|------|--------|--------------|
| CREAMM Act | Active | 2026-08-26 |
| Medical Cannabis Act | Active | 2026-08-26 |
| S2564 (home grow) | Pending (not advanced) | 2026-08-26 |
| A1674/S1758 (medical home grow) | Pending (not advanced) | 2026-08-26 |

No home cultivation legislation has passed as of August 2026. Multiple bills have been introduced but blocked by Assembly Health Committee Chair Herb Conaway.

---

## Possession Limits

| Product Type | Legal Limit | Over-Limit Penalty |
|--------------|-------------|-------------------|
| Cannabis flower / products | 6 oz total | Disorderly persons offense |
| Home storage | No explicit statutory limit | N/A |
| Plants (home grow) | 0 (prohibited) | 3rd degree crime: 3-5 years prison, $25,000 fine |

### Penalty Tiers for Over-Limit Possession

| Amount | Classification | Penalty |
|--------|-----------------|---------|
| Over 6 oz | Disorderly persons | Up to 6 months jail, $1,000 fine |

### Cultivation Penalties

| Amount | Classification | Penalty |
|--------|-----------------|---------|
| 1 oz - less than 5 lbs | 3rd Degree Crime | 3-5 years prison, $25,000 fine |
| 5-25 lbs | 2nd Degree Crime | 5-10 years prison, $150,000 fine |
| 25+ lbs | 1st Degree Crime | 10-20 years prison, $300,000 fine |

---

## Home Cultivation Rules

- **Recreational users**: NOT permitted. Home cultivation is a criminal offense.
- **Medical patients**: NOT permitted. Even registered medical patients cannot grow their own medicine.
- **Pending legislation**: S2564 would allow 6 plants per adult (12 per household) for recreational use. A1674/S1758 would allow 4 mature + 4 immature plants for medical patients. Neither has passed.
- **Hemp cultivation**: Legal with NJDA license ($50 application, $300 + $15/acre license fee).

---

## Purchase and Retail

- **Age**: 21+ for recreational; 18+ with medical certification.
- **Licensed retailers**: New Jersey Cannabis Regulatory Commission (NJ-CRC) licenses required.
- **Taxes**: 6.625% state sales tax + Social Equity Excise Fee + up to 2% local municipal tax.
- **Medical exemption**: Medical cannabis is tax-exempt.
- **Delivery**: Available through licensed retailers.
- **Local opt-out**: Municipalities may ban cannabis businesses within their borders.

---

## Consumption Rules

- **Private property**: Legal with property owner's permission.
- **Public spaces**: Illegal. Includes sidewalks, parks, and most outdoor areas.
- **Vehicles**: Illegal to consume or possess open container while driving.
- **Workplaces**: Employers may prohibit cannabis use and maintain drug-free workplace policies.

---

## DUI / Impairment

- **Standard**: It is illegal to operate a motor vehicle while under the influence of cannabis (N.J.S.A. 39:4-50).
- **Per se limit**: No specific THC blood concentration limit.
- **Penalties**: First offense DWI - up to 30 days jail, $250-$400 fine, license suspension 3 months-1 year, IDRC program.

---

## Employment Protections

- **No comprehensive statutory protection**: New Jersey does not have broad employment protections for off-duty recreational cannabis use.
- **Medical patients**: Some protections under the Jake Honig Act, but employers may still prohibit use in safety-sensitive positions.
- **Federal contractors**: Subject to federal Drug-Free Workplace Act.

---

## Federal Conflict Notes

- **Schedule I federally**: Recreational cannabis remains Schedule I under federal law.
- **Medical rescheduling**: FDA-approved products and state-licensed medical cannabis reclassified to Schedule III effective April 23, 2026.
- **Federal property**: Illegal on federal land and in federal buildings.

---

## Distinctive State Features

1. **No home cultivation**: New Jersey is one of only a handful of legal states (alongside Illinois, Washington, and Delaware) that prohibits home cultivation for all users, including medical patients.
2. **Industry opposition**: Cannabis retailers have lobbied against home grow bills to protect retail tax revenue.
3. **Generous possession limit**: 6 oz is among the highest public possession limits in the nation.
4. **Social Equity Excise Fee**: Revenue directed to communities disproportionately impacted by the War on Drugs.

---

## Cross-State Comparison Table

| Feature | New Jersey | National Average |
|---------|------------|------------------|
| Recreational legal | Yes | ~24 states |
| Medical legal | Yes | ~38 states |
| Home cultivation | No | ~20 states |
| Possession limit | 6 oz (high) | ~1-3 oz typical |
| Employment protections | Limited | ~10 states |

---

## Recording Consent Rules

New Jersey is a **one-party consent** state for audio recordings. N.J.S.A. 2A:156A-3 makes it a crime to record a private communication without the consent of at least one party.

---

## Practical Notes

- Do NOT attempt to grow cannabis at home in New Jersey - it is a serious criminal offense.
- The 6 oz possession limit is generous, but unlicensed cultivation carries severe penalties.
- Medical patients must purchase from licensed Alternative Treatment Centers; no home growing allowed.
- Municipalities can opt out of cannabis businesses; check local ordinances.
- Home grow bills have been introduced annually but have not advanced past committee.

---

## Related Entries

- [marijuana-laws-ny.md](marijuana-laws-ny.md) - New York (neighbor, recreational with home grow)
- [marijuana-laws-pa.md](marijuana-laws-pa.md) - Pennsylvania (neighbor, medical only)
- [marijuana-laws-de.md](marijuana-laws-de.md) - Delaware (neighbor, recreational, no home grow)
- [tenant-rights-nj.md](tenant-rights-nj.md) - New Jersey Tenant Rights

---

*Review date: 2026-08-26. This entry reflects statutes current as of that date. Always verify with current official sources before relying on this information.*
