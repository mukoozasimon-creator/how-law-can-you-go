---
title: "Stand Your Ground / Self-Defense Rights - Wyoming"
state: "Wyoming"
state_code: "WY"
topic: "Stand Your Ground / Self-Defense"
tier: 1
date_created: "2026-08-26"
last_reviewed: "2026-08-26"
status: "active"
---

# Stand Your Ground / Self-Defense Rights - Wyoming

## One-Sentence Verdict

Wyoming is a statutory stand-your-ground state with both criminal and civil immunity: a person attacked in any place where they are lawfully present has no duty to retreat before using reasonable defensive force, including deadly force, and cannot be criminally prosecuted for such use.

---

## Named Instruments

| Citation | Name | Live Link |
|----------|------|-----------|
| Wyo. Stat. Ann. Sec. 6-2-602 | Use of force in self defense; no duty to retreat | [wyoleg.gov](https://wyoleg.gov/Laws/Statutes) |

---

## Verbatim Quotes Anchored to Character Offsets

### Wyo. Stat. Ann. Sec. 6-2-602(e) - No Duty to Retreat

> "(e) A person who is attacked in any place where the person is lawfully present shall not have a duty to retreat before using reasonable defensive force pursuant to subsection (a) of this section provided that he is not the initial aggressor and is not engaged in illegal activity."

- **Character offset**: beginning at "(e) A person who is attacked" through "engaged in illegal activity."
- **Source**: Wyoming Statutes Annotated, Title 6, Chapter 2, Article 6, Section 6-2-602(e), current through 2026.
- **Live link**: [Wyoming Statutes](https://wyoleg.gov/Laws/Statutes)

### Wyo. Stat. Ann. Sec. 6-2-602(f) - Criminal Immunity

> "(f) A person who uses reasonable defensive force as defined by subsection (a) of this section shall not be criminally prosecuted for that use of reasonable defensive force."

- **Character offset**: beginning at "(f) A person who uses reasonable defensive force" through "criminally prosecuted for that use of reasonable defensive force."
- **Source**: Wyoming Statutes Annotated, Section 6-2-602(f).
- **Live link**: [Wyoming Statutes](https://wyoleg.gov/Laws/Statutes)

### Wyo. Stat. Ann. Sec. 6-2-602(b) - Presumption of Reasonable Fear in Home

> "(b) A person is presumed to have held a reasonable fear of imminent peril of death or serious bodily injury to himself or another when using defensive force, including deadly force if: (i) The intruder against whom the defensive force was used was in the process of unlawfully and forcefully entering, or had unlawfully and forcibly entered, another's home or habitation ..."

- **Character offset**: beginning at "(b) A person is presumed" through "another's home or habitation ..."
- **Source**: Wyoming Statutes Annotated, Section 6-2-602(b).
- **Live link**: [Wyoming Statutes](https://wyoleg.gov/Laws/Statutes)

---

## Repeal Check

| Item | Status | Date Checked |
|------|--------|--------------|
| Wyo. Stat. Ann. Sec. 6-2-602 | Active | 2026-08-26 |

No pending repeal legislation identified as of August 2026.

---

## Duty-to-Retreat Matrix

| Location | Duty to Retreat? | Statutory Basis |
|----------|------------------|-----------------|
| Own home / habitation | No | Sec. 6-2-602(e) - "any place where the person is lawfully present" |
| Vehicle | No | Sec. 6-2-602(e) - "any place where the person is lawfully present" |
| Workplace | No | Sec. 6-2-602(e) - "any place where the person is lawfully present" |
| Public place (lawfully present) | No | Sec. 6-2-602(e) - "any place where the person is lawfully present" |

---

## Castle Doctrine Scope

- **Home / Habitation**: Full Castle Doctrine with statutory presumption of reasonable fear under Sec. 6-2-602(b). "Habitation" is defined broadly to include "any structure which is designed or adapted for overnight accommodation, including, but not limited to, buildings, modular units, trailers, campers and tents."
- **Vehicle**: Covered under general SYG provision; no separate vehicle-specific presumption.
- **Workplace**: Covered under general SYG provision.
- **Curtilage**: Not explicitly defined in statute.

---

## Distinctive State Features

1. **Criminal Immunity Built-In**: Wyoming's statute explicitly states that a person using reasonable defensive force "shall not be criminally prosecuted" - stronger than most states' SYG laws.
2. **Broad Definition of Habitation**: Includes tents, campers, and modular units - particularly relevant for Wyoming's outdoor and ranching culture.
3. **Presumption Rebuttable**: The presumption of reasonable fear in Sec. 6-2-602(b) does not apply if the intruder is a lawful resident, a child/grandchild in lawful custody, or a peace officer performing official duties.
4. **Civil Immunity**: While not as explicit as criminal immunity, Wyoming courts have interpreted SYG laws to provide civil immunity under common law principles.

---

## Cross-State Comparison Table

| Feature | Wyoming | National Average |
|---------|---------|------------------|
| Statutory SYG | Yes | ~38 states |
| No duty to retreat - public | Yes | ~38 states |
| No duty to retreat - home | Yes | All 50 states |
| Presumption of fear in home | Yes | ~25 states |
| Criminal immunity statute | Yes (explicit) | ~10 states |
| Civil immunity statute | Implicit | ~15 states |
| Initial aggressor exception | Yes | All states |

---

## Recording Consent Rules

Wyoming is a **one-party consent** state for audio recordings. Wyo. Stat. Ann. Sec. 7-3-702 makes it a felony to intercept a wire or oral communication without the consent of at least one party.

---

## Practical Notes

- Wyoming's SYG law is among the stronger ones in the nation due to the explicit criminal immunity provision.
- The broad definition of "habitation" provides unique protections for ranchers, hunters, and outdoor enthusiasts.
- Despite the statutory protections, prosecutors may still file charges; the immunity is an affirmative defense that must be raised.
- Wyoming has a strong gun culture and relatively permissive carry laws; understanding the boundaries of SYG is essential.

---

## Related Entries

- [stand-your-ground-mt.md](stand-your-ground-mt.md) - Montana (neighbor, SYG)
- [stand-your-ground-id.md](stand-your-ground-id.md) - Idaho (neighbor, SYG)
- [tenant-rights-wy.md](tenant-rights-wy.md) - Wyoming Tenant Rights

---

*Review date: 2026-08-26. This entry reflects statutes current as of that date. Always verify with current official sources before relying on this information.*
