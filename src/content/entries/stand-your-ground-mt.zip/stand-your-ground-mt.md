---
title: "Stand Your Ground / Self-Defense Rights - Montana"
state: "Montana"
state_code: "MT"
topic: "Stand Your Ground / Self-Defense"
tier: 1
date_created: "2026-08-26"
last_reviewed: "2026-08-26"
status: "active"
---

# Stand Your Ground / Self-Defense Rights - Montana

## One-Sentence Verdict

Montana is a statutory stand-your-ground state: a person who is lawfully in any place and is threatened with bodily injury or loss of life has no duty to retreat from the threat or summon law enforcement before using force.

---

## Named Instruments

| Citation | Name | Live Link |
|----------|------|-----------|
| Mont. Code Ann. Sec. 45-3-110 | No duty to summon help or flee | [leg.mt.gov](https://leg.mt.gov/bills/mca/title_0450/chapter_0030/part_0010/section_0100/0450-0030-0010-0100.html) |
| Mont. Code Ann. Sec. 45-3-102 | Use of force in defense of person | [leg.mt.gov](https://leg.mt.gov/bills/mca/title_0450/chapter_0030/part_0010/section_0020/0450-0030-0010-0020.html) |
| Mont. Code Ann. Sec. 45-3-103 | Use of force in defense of occupied structure | [leg.mt.gov](https://leg.mt.gov/bills/mca/title_0450/chapter_0030/part_0010/section_0030/0450-0030-0010-0030.html) |

---

## Verbatim Quotes Anchored to Character Offsets

### Mont. Code Ann. Sec. 45-3-110 - No Duty to Summon Help or Flee

> "Except as provided in 45-3-105, a person who is lawfully in a place or location and who is threatened with bodily injury or loss of life has no duty to retreat from a threat or summon law enforcement assistance prior to using force. The provisions of this section apply to a person offering evidence of justifiable use of force under 45-3-102, 45-3-103, or 45-3-104."

- **Character offset**: beginning at "Except as provided in 45-3-105" through "45-3-102, 45-3-103, or 45-3-104."
- **Source**: Montana Code Annotated, Title 45, Chapter 3, Part 1, Section 45-3-110, current through 2026.
- **Live link**: [Montana Code Annotated](https://leg.mt.gov/bills/mca/title_0450/chapter_0030/part_0010/section_0100/0450-0030-0010-0100.html)

---

## Repeal Check

| Item | Status | Date Checked |
|------|--------|--------------|
| Mont. Code Ann. Sec. 45-3-110 | Active | 2026-08-26 |
| Mont. Code Ann. Sec. 45-3-102 | Active | 2026-08-26 |
| Mont. Code Ann. Sec. 45-3-103 | Active | 2026-08-26 |

No pending repeal legislation identified as of August 2026.

---

## Duty-to-Retreat Matrix

| Location | Duty to Retreat? | Statutory Basis |
|----------|------------------|-----------------|
| Own home / occupied structure | No | Sec. 45-3-110 - "lawfully in a place or location" |
| Vehicle | No | Sec. 45-3-110 - "lawfully in a place or location" |
| Workplace | No | Sec. 45-3-110 - "lawfully in a place or location" |
| Public place (lawfully present) | No | Sec. 45-3-110 - "lawfully in a place or location" |

---

## Castle Doctrine Scope

- **Home / Occupied Structure**: Full protection under Sec. 45-3-103. A person may use force to prevent unlawful entry into an occupied structure. Deadly force is permitted if the other person enters the structure and the force is necessary to prevent assault or the commission of a forcible felony.
- **Vehicle**: Treated as an occupied structure or covered under the general SYG provision.
- **Workplace**: Covered under the general SYG provision.
- **Curtilage**: Not explicitly defined; case law may extend protections.

---

## Distinctive State Features

1. **No Duty to Summon Help**: Montana's statute is unique in explicitly stating there is no duty to "summon law enforcement assistance" before using force - going beyond the typical no-duty-to-retreat language.
2. **Applies to All Justifiable Force**: Sec. 45-3-110 applies not only to defense of person (45-3-102) but also to defense of occupied structures (45-3-103) and other property (45-3-104).
3. **Aggressor Exception**: Sec. 45-3-105 (referenced in 45-3-110) limits the SYG right for initial aggressors who must withdraw and communicate intent to do so before regaining the right to self-defense.
4. **No Explicit Immunity**: Montana does not have a standalone criminal or civil immunity statute for SYG cases.

---

## Cross-State Comparison Table

| Feature | Montana | National Average |
|---------|---------|------------------|
| Statutory SYG | Yes | ~38 states |
| No duty to retreat - public | Yes | ~38 states |
| No duty to retreat - home | Yes | All 50 states |
| No duty to summon police | Yes (explicit) | Rare |
| Presumption of fear in home | No explicit presumption | ~25 states |
| Civil immunity statute | No | ~15 states |
| Criminal immunity statute | No | ~10 states |
| Initial aggressor exception | Yes | All states |

---

## Recording Consent Rules

Montana is a **one-party consent** state for audio recordings. Mont. Code Ann. Sec. 45-8-213 makes it a misdemeanor to record a private communication without the consent of at least one party.

---

## Practical Notes

- Montana's SYG law is straightforward and broadly applicable. The explicit "no duty to summon help" language is unusual and provides additional protection.
- The state has a strong outdoor and rural culture where law enforcement may be far away, making self-defense rights particularly relevant.
- Montana's "Make My Day" law (Sec. 45-3-103) provides additional protections for occupied structures.
- As with all SYG states, the use of force must still be "reasonable" and "necessary" under the circumstances.

---

## Related Entries

- [stand-your-ground-wy.md](stand-your-ground-wy.md) - Wyoming (neighbor, SYG with criminal immunity)
- [stand-your-ground-id.md](stand-your-ground-id.md) - Idaho (neighbor, SYG)
- [tenant-rights-mt.md](tenant-rights-mt.md) - Montana Tenant Rights

---

*Review date: 2026-08-26. This entry reflects statutes current as of that date. Always verify with current official sources before relying on this information.*
