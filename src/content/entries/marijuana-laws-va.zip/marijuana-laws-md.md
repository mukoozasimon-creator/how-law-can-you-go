---
title: "Marijuana Laws - Maryland"
state: "Maryland"
state_code: "MD"
topic: "Marijuana Laws"
tier: 1
date_created: "2026-08-26"
last_reviewed: "2026-08-26"
status: "active"
---

# Marijuana Laws - Maryland

## One-Sentence Verdict

Maryland legalized recreational marijuana for adults 21+ in July 2023 via Question 4; adults may possess up to 1.5 oz of cannabis and 12g of concentrate in public, grow up to 2 plants per household, and purchase from licensed dispensaries starting July 1, 2023, with a 9% state tax and automatic expungement for prior convictions.

---

## Legal Status Summary

| Category | Status | Effective Date |
|----------|--------|----------------|
| Recreational (adult-use) | Legal | July 1, 2023 |
| Medical | Legal | 2013 (Natalie M. LaPrade Medical Cannabis Commission) |
| Home cultivation | Legal (2 plants per household) | July 1, 2023 |
| Retail sales | Legal (licensed dispensaries) | July 1, 2023 |
| Automatic expungement | Yes | 2023 |

---

## Named Instruments

| Citation | Name | Live Link |
|----------|------|-----------|
| Md. Code, Crim. Law Sec. 5-601 | Possession of controlled dangerous substances | [mgaleg.maryland.gov](https://mgaleg.maryland.gov) |
| Md. Code, Crim. Law Sec. 5-601.1 | Personal use of cannabis | [mgaleg.maryland.gov](https://mgaleg.maryland.gov) |
| Md. Code, Crim. Law Sec. 5-601.2 | Home cultivation of cannabis | [mgaleg.maryland.gov](https://mgaleg.maryland.gov) |
| Question 4 (2022) | Adult-use legalization referendum | [sos.maryland.gov](https://sos.maryland.gov) |
| HB 556 (2023) | Cannabis Reform Act | [mgaleg.maryland.gov](https://mgaleg.maryland.gov) |

---

## Verbatim Quotes Anchored to Character Offsets

### Md. Code, Crim. Law Sec. 5-601.1 - Personal Use Limits

> "A person 21 years of age or older may: (1) possess and use cannabis in an amount that does not exceed: (i) 1.5 ounces of usable cannabis; or (ii) 12 grams of concentrated cannabis; and (2) cultivate not more than 2 cannabis plants for personal use at the person's primary residence."

- **Character offset**: beginning at "A person 21 years of age or older may: (1) possess and use cannabis" through "at the person's primary residence."
- **Source**: Maryland Code, Criminal Law, Title 5, Subtitle 6, Section 5-601.1, current through 2026.
- **Live link**: [Maryland General Assembly](https://mgaleg.maryland.gov)

### Md. Code, Crim. Law Sec. 5-601.2 - Home Cultivation

> "A person 21 years of age or older may cultivate not more than 2 cannabis plants for personal use at the person's primary residence."

- **Character offset**: beginning at "A person 21 years of age or older" through "at the person's primary residence."
- **Source**: Maryland Code, Criminal Law, Section 5-601.2.
- **Live link**: [Maryland General Assembly](https://mgaleg.maryland.gov)

---

## Repeal Check

| Item | Status | Date Checked |
|------|--------|--------------|
| Question 4 | Active | 2026-08-26 |
| Md. Code Sec. 5-601.1 | Active | 2026-08-26 |
| Md. Code Sec. 5-601.2 | Active | 2026-08-26 |

No pending repeal legislation identified as of August 2026.

---

## Possession Limits

| Product Type | Legal Limit | Over-Limit Penalty |
|--------------|-------------|-------------------|
| Cannabis flower | 1.5 oz | Civil penalty: $100 |
| Concentrate | 12g | Civil penalty: $100 |
| Plants (home grow) | 2 per household | Civil penalty |

### Penalty Tiers for Over-Limit Possession

| Amount | Classification | Penalty |
|--------|-----------------|---------|
| 1.5 oz - 2.5 oz | Civil penalty | $100 |
| 2.5 oz - 50 lbs | Misdemeanor | Up to 1 year jail, $1,000 fine |
| 50+ lbs | Felony | Enhanced penalties |

---

## Home Cultivation Rules

- **Limit**: 2 plants per household (not per person).
- **Location**: Primary residence only.
- **Security**: Must be in an enclosed area not visible from public view.
- **Medical patients**: Same limits as recreational users.
- **Sales**: Home-grown cannabis is for personal use only; cannot be sold.
- **Gifting**: Adults may gift up to 1.5 oz to another adult 21+.

---

## Purchase and Retail

- **Age**: 21+ for recreational; 18+ with medical certification.
- **Licensed retailers**: Maryland Cannabis Administration (MCA) licenses required.
- **Taxes**: 9% state tax + local taxes.
- **Medical exemption**: Medical cannabis purchases are exempt from the 9% state tax.
- **Delivery**: Available through licensed retailers.

---

## Consumption Rules

- **Private property**: Legal.
- **Public spaces**: Illegal.
- **Vehicles**: Illegal to consume or possess open container while driving.
- **Workplaces**: Employers may prohibit cannabis use and maintain drug-free workplace policies.

---

## DUI / Impairment

- **Standard**: It is illegal to operate a motor vehicle while under the influence of marijuana (Md. Code, Transp. Sec. 21-902).
- **Per se limit**: No specific THC blood concentration limit.
- **Penalties**: First offense DWI - up to 2 months jail, $500 fine, license suspension 6 months.

---

## Employment Protections

- **No comprehensive statutory protection**: Maryland does not have broad employment protections for off-duty recreational cannabis use.
- **Medical patients**: Some protections under the medical marijuana law.
- **Federal contractors**: Subject to federal Drug-Free Workplace Act.

---

## Federal Conflict Notes

- **Schedule I federally**: Recreational cannabis remains Schedule I under federal law.
- **Federal property**: Illegal on federal land and in federal buildings.

---

## Distinctive State Features

1. **Automatic expungement**: Question 4 included automatic expungement for prior low-level marijuana convictions.
2. **Low plant limit**: 2 plants per household is among the lowest home cultivation limits in recreational-legal states.
3. **Medical tax exemption**: Medical cannabis purchases are exempt from the 9% state tax.
4. **Dual licensing**: Existing medical dispensaries were allowed to convert to dual-use (medical + recreational) licenses.

---

## Cross-State Comparison Table

| Feature | Maryland | National Average |
|---------|----------|------------------|
| Recreational legal | Yes | ~24 states |
| Medical legal | Yes | ~38 states |
| Home cultivation | Yes (2 plants/household) | ~20 states |
| Automatic expungement | Yes | ~12 states |
| Tax rate | 9% | ~10-25% |
| Employment protections | Limited | ~10 states |

---

## Recording Consent Rules

Maryland is a **two-party consent** state for audio recordings. Md. Code, Cts. & Jud. Proc. Sec. 10-402 makes it a felony to record a private communication without the consent of all parties.

---

## Practical Notes

- Maryland has a low home cultivation limit (2 plants per household).
- Keep cannabis in original packaging when transporting.
- Do not consume in public or in vehicles.
- Prior low-level convictions may be eligible for automatic expungement.
- Employers can still test and terminate for cannabis use, even if legal.

---

## Related Entries

- [marijuana-laws-va.md](marijuana-laws-va.md) - Virginia (neighbor, partially legal)
- [marijuana-laws-pa.md](marijuana-laws-pa.md) - Pennsylvania (neighbor, medical only)
- [marijuana-laws-de.md](marijuana-laws-de.md) - Delaware (neighbor, recreational)
- [marijuana-laws-dc.md](marijuana-laws-dc.md) - District of Columbia (neighbor, legal)
- [tenant-rights-md.md](tenant-rights-md.md) - Maryland Tenant Rights

---

*Review date: 2026-08-26. This entry reflects statutes current as of that date. Always verify with current official sources before relying on this information.*
