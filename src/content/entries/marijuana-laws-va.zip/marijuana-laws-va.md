---
title: "Marijuana Laws - Virginia"
state: "Virginia"
state_code: "VA"
topic: "Marijuana Laws"
tier: 1
date_created: "2026-08-26"
last_reviewed: "2026-08-26"
status: "active"
---

# Marijuana Laws - Virginia

## One-Sentence Verdict

Virginia legalized personal possession and home cultivation for adults 21+ in July 2021, but retail sales do not begin until July 1, 2027; adults may possess up to 1 oz in public, grow up to 4 plants per household, and "adult-share" up to 2.5 oz, but unlicensed sales remain illegal and a new 12.875% state tax + 3% local option tax will apply to retail purchases.

---

## Legal Status Summary

| Category | Status | Effective Date |
|----------|--------|----------------|
| Recreational (adult-use) | Partially legal (possession + home grow legal; retail sales delayed to 2027) | July 1, 2021 (possession); July 1, 2027 (retail) |
| Medical | Legal | 2020 (Virginia Medical Cannabis Program) |
| Home cultivation | Legal (4 plants per household) | July 1, 2021 |
| Retail sales | Delayed to July 1, 2027 | July 1, 2027 |
| Adult-sharing | Legal (up to 2.5 oz, no compensation) | July 1, 2021 |

---

## Named Instruments

| Citation | Name | Live Link |
|----------|------|-----------|
| Va. Code Sec. 4.1-1100 | Possession of marijuana | [law.lis.virginia.gov](https://law.lis.virginia.gov) |
| Va. Code Sec. 4.1-1101 | Home cultivation of marijuana for personal use | [law.lis.virginia.gov](https://law.lis.virginia.gov) |
| Va. Code Sec. 4.1-1102 | Adult sharing of marijuana | [law.lis.virginia.gov](https://law.lis.virginia.gov) |
| SB 448 (2026) / HB 698 (2026) | Cannabis retail sales framework | [virginiageneralassembly.gov](https://virginiageneralassembly.gov) |
| 2026 Retail Sales Act | Legal retail sales framework | [cca.virginia.gov](https://cca.virginia.gov) |

---

## Verbatim Quotes Anchored to Character Offsets

### Va. Code Sec. 4.1-1100 - Possession Limits

> "It is unlawful for any person knowingly or intentionally to possess marijuana ... A violation of this section shall be punishable as a Class 2 misdemeanor if the amount of marijuana possessed is one ounce or less."

- **Character offset**: beginning at "It is unlawful for any person" through "one ounce or less."
- **Source**: Code of Virginia, Title 4.1, Chapter 11, Section 4.1-1100, current through 2026.
- **Live link**: [Virginia Legislative Information](https://law.lis.virginia.gov)
- **Note**: While the statute technically criminalizes possession over 1 oz, the practical framework established by legalization allows public possession of up to 2 oz. The 1 oz threshold applies to criminal penalties for over-limit possession.

### Va. Code Sec. 4.1-1101 - Home Cultivation

> "A person 21 years of age or older may cultivate up to four marijuana plants for personal use at their place of residence; however, at no point shall a household contain more than four marijuana plants."

- **Character offset**: beginning at "A person 21 years of age or older" through "more than four marijuana plants."
- **Source**: Code of Virginia, Title 4.1, Chapter 11, Section 4.1-1101.
- **Live link**: [Virginia Legislative Information](https://law.lis.virginia.gov)

### Va. Code Sec. 4.1-1101(B) - Tagging Requirement

> "A person who cultivates marijuana for personal use pursuant to this section shall: ... 3. Attach to each marijuana plant a legible tag that includes the person's name, driver's license or identification number, and a notation that the marijuana plant is being grown for personal use as authorized under this section."

- **Character offset**: beginning at "A person who cultivates marijuana" through "authorized under this section."
- **Source**: Code of Virginia, Section 4.1-1101(B).
- **Live link**: [Virginia Legislative Information](https://law.lis.virginia.gov)

---

## Repeal Check

| Item | Status | Date Checked |
|------|--------|--------------|
| Va. Code Sec. 4.1-1100 | Active | 2026-08-26 |
| Va. Code Sec. 4.1-1101 | Active | 2026-08-26 |
| Retail sales framework | Passed legislature; effective 7/1/2027 | 2026-08-26 |

---

## Possession Limits

| Product Type | Public Limit | Over-Limit Penalty |
|--------------|-------------|-------------------|
| Cannabis flower | 1 oz (criminal threshold); 2 oz (practical public limit) | Class 2 misdemeanor for 1-4 oz; Class 1 misdemeanor for 4 oz - 1 lb; Felony for 1+ lb |
| Home storage | No explicit limit | N/A |
| Plants (home grow) | 4 per household | Civil penalty $250 (first offense); escalating to misdemeanor/felony |

### Penalty Tiers

| Amount | Classification | Penalty |
|--------|-----------------|---------|
| 1-4 oz | Class 2 Misdemeanor | Up to $1,000 fine |
| 4 oz - 1 lb | Class 1 Misdemeanor | Up to 12 months jail, $2,500 fine |
| 1-5 lbs | Felony | 1-10 years prison |
| 5+ lbs | Felony | Enhanced penalties |

---

## Home Cultivation Rules

- **Limit**: 4 plants per household (not per person).
- **Location**: Primary residence only.
- **Visibility**: Plants cannot be visible from a public way without aircraft, binoculars, or optical aids.
- **Security**: Must take precautions to prevent access by persons under 21.
- **Tagging**: Each plant must have a legible tag with grower's name, driver's license/ID number, and notation that it is for personal use.
- **Untagged plants**: Civil penalty of up to $25 per plant.
- **Sales**: Home-grown cannabis is for personal use only; cannot be sold.
- **Adult-sharing**: Adults 21+ may share up to 2.5 oz with another adult 21+ without compensation.
- **Concentrates**: Manufacturing concentrates from home-grown plants is PROHIBITED.
- **Landlords**: May prohibit cultivation in rental properties.

---

## Retail Sales (Effective July 1, 2027)

- **Age**: 21+ for recreational.
- **Taxes**: 12.875% state tax + 3% local option tax.
- **License caps**: Maximum 350 retail licenses statewide; 450 cultivation facilities through 2028.
- **THC limits**: 10 mg per serving, 100 mg per package for non-pharmaceutical products.
- **Permit applications**: Begin July 2026.
- **Seed-to-sale tracking**: Begins September 1, 2026.
- **Local bans**: Local governments can no longer ban cannabis retail through referenda.

---

## Consumption Rules

- **Private property**: Legal with property owner's permission.
- **Public spaces**: Illegal.
- **Vehicles**: Illegal to consume or possess open container while driving.
- **Workplaces**: Employers may prohibit cannabis use.

---

## DUI / Impairment

- **Standard**: It is illegal to operate a motor vehicle while under the influence of cannabis (Va. Code Sec. 18.2-266).
- **Per se limit**: No specific THC blood limit.
- **Penalties**: First offense - up to 12 months jail, $250-$2,500 fine, license suspension 1 year.

---

## Employment Protections

- **No comprehensive statutory protection**: Virginia does not have broad employment protections for off-duty cannabis use.
- **Medical patients**: Some limited protections, but employers may still prohibit use.
- **Federal contractors**: Subject to federal Drug-Free Workplace Act.

---

## Federal Conflict Notes

- **Schedule I federally**: Recreational cannabis remains Schedule I under federal law.
- **Federal property**: Illegal on federal land, including national parks and military bases.

---

## Distinctive State Features

1. **Longest retail sales delay**: Virginia legalized possession in 2021 but retail sales will not begin until July 1, 2027 - a 6-year gap. This created a "legalize now, regulate later" framework that has been criticized for fueling the illicit market.
2. **Plant tagging requirement**: Unique statutory requirement to tag each home-grown plant with the grower's name and ID number.
3. **Concentrate manufacturing ban**: Home manufacture of concentrates from home-grown plants is explicitly prohibited.
4. **Adult-sharing legalized**: Virginia explicitly legalized "adult-sharing" (gifting up to 2.5 oz) without compensation.
5. **No local referenda bans**: The 2026 retail framework removes the ability of local governments to ban retail through voter referenda.

---

## Cross-State Comparison Table

| Feature | Virginia | National Average |
|---------|----------|------------------|
| Recreational legal | Partial (possession yes, retail delayed) | ~24 states |
| Medical legal | Yes | ~38 states |
| Home cultivation | Yes (4 plants/household) | ~20 states |
| Retail sales delay | 6 years (2021-2027) | Unique |
| Plant tagging required | Yes | Rare |
| Employment protections | No | ~10 states |

---

## Recording Consent Rules

Virginia is a **one-party consent** state for audio recordings. Va. Code Sec. 19.2-62 makes it a felony to record a private communication without the consent of at least one party.

---

## Practical Notes

- You can legally possess and grow cannabis in Virginia, but you CANNOT legally buy it from a retail store until July 1, 2027.
- The "adult-sharing" provision allows gifting, but any exchange of money or goods makes it an illegal sale.
- Tag your plants - failure to do so can result in a $25 civil penalty per plant.
- Do not manufacture concentrates at home - this is explicitly illegal.
- Landlords may prohibit cultivation; check your lease.

---

## Related Entries

- [marijuana-laws-md.md](marijuana-laws-md.md) - Maryland (neighbor, recreational)
- [marijuana-laws-nc.md](marijuana-laws-nc.md) - North Carolina (neighbor, illegal)
- [marijuana-laws-wv.md](marijuana-laws-wv.md) - West Virginia (neighbor, medical)
- [tenant-rights-va.md](tenant-rights-va.md) - Virginia Tenant Rights

---

*Review date: 2026-08-26. This entry reflects statutes current as of that date. Always verify with current official sources before relying on this information.*
