---
title: "Marijuana Laws - Michigan"
state: "Michigan"
state_code: "MI"
topic: "Marijuana Laws"
tier: 1
date_created: "2026-08-26"
last_reviewed: "2026-08-26"
status: "active"
---

# Marijuana Laws - Michigan

## One-Sentence Verdict

Michigan legalized recreational marijuana for adults 21+ in December 2018 via Proposal 1 (MRTMA); adults may possess up to 2.5 oz in public, store up to 10 oz at home, cultivate up to 12 plants per residence, and purchase from licensed dispensaries, with a 10% excise tax and a new 24% wholesale tax effective January 2026.

---

## Legal Status Summary

| Category | Status | Effective Date |
|----------|--------|----------------|
| Recreational (adult-use) | Legal | December 6, 2018 |
| Medical | Legal | 2008 (MMMA) |
| Home cultivation | Legal (12 plants per residence) | December 6, 2018 |
| Retail sales | Legal (licensed dispensaries) | December 2019 |
| Social consumption | Legal (licensed consumption lounges) | 2023 |

---

## Named Instruments

| Citation | Name | Live Link |
|----------|------|-----------|
| MCL 333.27951 et seq. | Michigan Regulation and Taxation of Marihuana Act (MRTMA) | [legislature.mi.gov](https://legislature.mi.gov) |
| MCL 333.26421 et seq. | Michigan Medical Marihuana Act (MMMA) | [legislature.mi.gov](https://legislature.mi.gov) |
| MCL 333.27955 | Personal possession limits | [legislature.mi.gov](https://legislature.mi.gov) |
| MCL 333.27958 | Home cultivation | [legislature.mi.gov](https://legislature.mi.gov) |
| MCL 333.27963 | Taxes | [legislature.mi.gov](https://legislature.mi.gov) |

---

## Verbatim Quotes Anchored to Character Offsets

### MCL 333.27955 - Possession Limits

> "(1) Except as provided in this section, and notwithstanding any other law or rule, the following acts by a person 21 years of age or older are not unlawful, are not an offense, are not grounds for seizing or forfeiting property, and are not grounds for arrest, prosecution, or penalty ... (a) Possessing, using, or consuming, internally possessing, or transporting 2.5 ounces or less of marihuana ... (b) Within the person's residence, possessing, storing, and processing not more than 10 ounces of marihuana."

- **Character offset**: beginning at "(1) Except as provided in this section" through "not more than 10 ounces of marihuana."
- **Source**: Michigan Compiled Laws, Act 420 of 2018 (MRTMA), Section 5, MCL 333.27955, current through 2026.
- **Live link**: [Michigan Legislature](https://legislature.mi.gov)

### MCL 333.27958 - Home Cultivation

> "(1) A person 21 years of age or older may cultivate not more than 12 marihuana plants in a single residence at 1 time for personal use. (2) The plants shall be cultivated in an enclosed, locked facility that is not visible from a public place without the use of binoculars, aircraft, or other optical aids."

- **Character offset**: beginning at "(1) A person 21 years of age or older" through "other optical aids."
- **Source**: Michigan Compiled Laws, Act 420 of 2018 (MRTMA), Section 8, MCL 333.27958.
- **Live link**: [Michigan Legislature](https://legislature.mi.gov)

---

## Repeal Check

| Item | Status | Date Checked |
|------|--------|--------------|
| MRTMA (MCL 333.27951) | Active | 2026-08-26 |
| MMMA (MCL 333.26421) | Active | 2026-08-26 |
| 24% wholesale tax (2026) | Active | 2026-08-26 |

No pending repeal legislation identified as of August 2026.

---

## Possession Limits

| Product Type | Public Limit | Home Storage Limit | Over-Limit Penalty |
|--------------|-------------|-------------------|-------------------|
| Cannabis flower | 2.5 oz | 10 oz | Civil infraction: fine up to $100 |
| Concentrate | 15g (part of 2.5 oz equivalent) | 10 oz equivalent | Civil infraction: fine up to $100 |
| Plants (home grow) | 12 per residence | N/A | Civil infraction: fine up to $100 |

### Penalty Tiers for Over-Limit Possession

| Amount | Classification | Penalty |
|--------|-----------------|---------|
| 2.5-5 oz | Civil infraction | Up to $500 fine |
| 5 oz - 2,000g | Misdemeanor | Up to 1 year jail, $2,000 fine |
| 2,000+ g | Felony | Enhanced penalties |

---

## Home Cultivation Rules

- **Limit**: 12 plants per residence (not per person).
- **Location**: Single residence only.
- **Enclosure**: Must be in an enclosed, locked facility.
- **Visibility**: Cannot be visible from a public place without binoculars, aircraft, or other optical aids.
- **Security**: Must have locks or other functioning security devices.
- **Sales**: Home-grown cannabis is for personal use only; cannot be sold.
- **Gifting**: Adults may gift up to 2.5 oz to another adult 21+, as long as the transfer is not promoted or advertised commercially.
- **Medical patients**: May cultivate up to 12 plants under MMMA; can also designate a caregiver.

---

## Purchase and Retail

- **Age**: 21+ for recreational; 18+ with medical card.
- **Licensed retailers**: Michigan Cannabis Regulatory Agency (CRA) licenses required.
- **Taxes**: 10% excise tax + 6% sales tax + NEW 24% wholesale tax (effective January 1, 2026).
- **Medical exemption**: Medical cannabis purchases are exempt from the 10% excise tax.
- **Delivery**: Available through licensed retailers.
- **Social consumption**: Licensed on-site consumption lounges are permitted.

---

## Consumption Rules

- **Private property**: Legal.
- **Public spaces**: Illegal. Civil infraction.
- **Vehicles**: Illegal to consume or possess open container while driving.
- **Workplaces**: Employers may prohibit cannabis use and maintain drug-free workplace policies.

---

## DUI / Impairment

- **Standard**: It is illegal to operate a motor vehicle while under the influence of marijuana (MCL 257.625).
- **Per se limit**: No specific THC blood concentration limit; impairment determined by field sobriety tests and officer observation.
- **Penalties**: First offense OWI - up to 93 days jail, $500 fine, license suspension 30-180 days, community service.

---

## Employment Protections

- **No comprehensive statutory protection**: Michigan does not have broad employment protections for off-duty recreational cannabis use.
- **Medical patients**: Some protections under MMMA, but employers may still prohibit use and test for cannabis in safety-sensitive positions.
- **Federal contractors**: Subject to federal Drug-Free Workplace Act.

---

## Federal Conflict Notes

- **Schedule I federally**: Recreational cannabis remains Schedule I under federal law.
- **Medical rescheduling**: FDA-approved products and state-licensed medical cannabis reclassified to Schedule III effective April 23, 2026.
- **Federal property**: Illegal on federal land and in federal buildings.
- **Federal housing**: Public housing may still prohibit cannabis use.

---

## Distinctive State Features

1. **Largest Midwest market**: Michigan has one of the largest legal cannabis markets in the Midwest.
2. **12-plant home grow**: Generous home cultivation limit (12 plants per residence).
3. **New 24% wholesale tax (2026)**: Significant tax increase effective January 2026, which may affect retail pricing.
4. **Social consumption lounges**: Licensed on-site consumption is permitted, unlike many states.
5. **Medical + recreational integration**: Dual-use system where medical patients have tax advantages.

---

## Cross-State Comparison Table

| Feature | Michigan | National Average |
|---------|----------|------------------|
| Recreational legal | Yes | ~24 states |
| Medical legal | Yes | ~38 states |
| Home cultivation | Yes (12 plants/residence) | ~20 states |
| Social consumption lounges | Yes | ~8 states |
| Tax rate | 10% excise + 6% sales + 24% wholesale | Varies |
| Employment protections | Limited | ~10 states |

---

## Recording Consent Rules

Michigan is a **two-party consent** state for audio recordings. MCL 750.539c makes it a felony to record a private conversation without the consent of all parties.

---

## Practical Notes

- Michigan has among the most generous home cultivation limits in the nation.
- The new 24% wholesale tax (effective 2026) may significantly increase retail prices.
- Keep cannabis in original packaging when transporting.
- Do not consume in public or in vehicles.
- Medical patients should carry their registry card and keep receipts.
- Social consumption lounges are available in some cities.

---

## Related Entries

- [marijuana-laws-oh.md](marijuana-laws-oh.md) - Ohio (neighbor, recreational)
- [marijuana-laws-in.md](marijuana-laws-in.md) - Indiana (neighbor, illegal)
- [marijuana-laws-il.md](marijuana-laws-il.md) - Illinois (neighbor, recreational, no home grow for recreational)
- [marijuana-laws-wi.md](marijuana-laws-wi.md) - Wisconsin (neighbor, illegal)
- [tenant-rights-mi.md](tenant-rights-mi.md) - Michigan Tenant Rights

---

*Review date: 2026-08-26. This entry reflects statutes current as of that date. Always verify with current official sources before relying on this information.*
