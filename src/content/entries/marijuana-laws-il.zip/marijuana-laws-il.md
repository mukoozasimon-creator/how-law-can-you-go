---
title: "Marijuana Laws - Illinois"
state: "Illinois"
state_code: "IL"
topic: "Marijuana Laws"
tier: 1
date_created: "2026-08-26"
last_reviewed: "2026-08-26"
status: "active"
---

# Marijuana Laws - Illinois

## One-Sentence Verdict

Illinois legalized recreational marijuana for adults 21+ on January 1, 2020, via the Cannabis Regulation and Tax Act (CRTA); residents may possess up to 30g of flower, 5g of concentrate, and 500mg of THC in infused products, but home cultivation is restricted to registered medical patients only (up to 5 plants).

---

## Legal Status Summary

| Category | Status | Effective Date |
|----------|--------|----------------|
| Recreational (adult-use) | Legal | January 1, 2020 |
| Medical | Legal | 2013 (Compassionate Use of Medical Cannabis Pilot Program Act) |
| Home cultivation | Medical only (5 plants for patients) | January 1, 2020 |
| Retail sales | Legal (licensed dispensaries) | January 1, 2020 |
| Social equity | Yes (state-mandated program) | 2020 |

---

## Named Instruments

| Citation | Name | Live Link |
|----------|------|-----------|
| 410 ILCS 705 | Cannabis Regulation and Tax Act (CRTA) | [ilga.gov](https://ilga.gov) |
| 410 ILCS 130 | Compassionate Use of Medical Cannabis Pilot Program Act | [ilga.gov](https://ilga.gov) |
| 410 ILCS 705/10-10 | Possession limits | [ilga.gov](https://ilga.gov) |
| 410 ILCS 705/10-5 | Home cultivation | [ilga.gov](https://ilga.gov) |

---

## Verbatim Quotes Anchored to Character Offsets

### 410 ILCS 705/10-10 - Possession Limits

> "A person who is an Illinois resident may possess: (1) not more than 30 grams of cannabis flower; (2) not more than 5 grams of cannabis concentrate; and (3) not more than 500 milligrams of THC contained in a cannabis-infused product."

- **Character offset**: beginning at "A person who is an Illinois resident" through "cannabis-infused product."
- **Source**: Illinois Compiled Statutes, 410 ILCS 705/10-10, current through 2026.
- **Live link**: [Illinois General Assembly](https://ilga.gov)

### 410 ILCS 705/10-5 - Home Cultivation (Medical Only)

> "A registered qualifying patient may cultivate cannabis plants, with a limit of 5 plants that are more than 5 inches tall, per household, without a cultivation center or craft grower license."

- **Character offset**: beginning at "A registered qualifying patient" through "craft grower license."
- **Source**: Illinois Compiled Statutes, 410 ILCS 705/10-5.
- **Live link**: [Illinois General Assembly](https://ilga.gov)

---

## Repeal Check

| Item | Status | Date Checked |
|------|--------|--------------|
| CRTA (410 ILCS 705) | Active | 2026-08-26 |
| Medical Cannabis Act (410 ILCS 130) | Active | 2026-08-26 |

No pending repeal legislation identified as of August 2026.

---

## Possession Limits

| Product Type | Resident Limit | Non-Resident Limit | Over-Limit Penalty |
|--------------|---------------|-------------------|-------------------|
| Cannabis flower | 30g | 15g | Misdemeanor: up to 1 year jail, $2,500 fine |
| Concentrate | 5g | 2.5g | Misdemeanor: up to 1 year jail, $2,500 fine |
| Infused products (THC) | 500mg | 250mg | Misdemeanor: up to 1 year jail, $2,500 fine |

### Penalty Tiers for Over-Limit Possession

| Amount | Classification | Penalty |
|--------|-----------------|---------|
| 30-100g | Misdemeanor | Up to 1 year jail, $2,500 fine |
| 100-500g | Felony (4) | 1-3 years prison, $25,000 fine |
| 500-2,000g | Felony (3) | 2-5 years prison, $25,000 fine |
| 2,000-5,000g | Felony (2) | 3-7 years prison, $25,000 fine |
| 5,000g+ | Felony (1) | 4-15 years prison, $25,000 fine |

---

## Home Cultivation Rules

- **Recreational users**: NOT permitted to cultivate. Home cultivation is medical-only in Illinois.
- **Medical patients**: Up to 5 plants per household that are more than 5 inches tall.
- **Location**: Must be in the patient's primary residence in a locked, enclosed space.
- **Security**: Must comply with all state regulations; local ordinances may impose additional restrictions.
- **Seeds**: Cannot be given or sold to non-qualifying patients.
- **Gifting**: Medical patients CANNOT gift away cannabis or cannabis products.

---

## Purchase and Retail

- **Age**: 21+ for recreational; under 18 with medical certification and caregiver.
- **Licensed retailers**: Illinois Department of Financial and Professional Regulation (IDFPR) licenses required.
- **Taxes**: State excise tax (10-25% depending on THC content), state sales tax (6.25%), local taxes vary.
- **Delivery**: Not currently allowed for recreational; medical delivery permitted.
- **Social equity**: State-mandated social equity licensing program for justice-involved individuals and residents of disproportionately impacted areas.

---

## Consumption Rules

- **Private property**: Legal.
- **Public spaces**: Illegal. Includes sidewalks, parks, and most outdoor areas.
- **Vehicles**: Illegal to consume or possess open container while driving.
- **Workplaces**: Employers may prohibit cannabis use and maintain drug-free workplace policies.
- **Landlords**: May prohibit cannabis use in rental properties.

---

## DUI / Impairment

- **Standard**: It is illegal to operate a motor vehicle while under the influence of cannabis (625 ILCS 5/11-501).
- **Per se limit**: No specific THC blood concentration limit; impairment determined by field sobriety tests.
- **Penalties**: First offense - up to 1 year jail, $2,500 fine, license suspension 6 months-1 year.

---

## Employment Protections

- **No comprehensive statutory protection**: Illinois does not have broad employment protections for off-duty cannabis use.
- **Medical patients**: Some protections under the Illinois Human Rights Act for medical use, but case law is evolving.
- **Employers**: May maintain drug-free workplace policies and test for cannabis.
- **Federal contractors**: Subject to federal Drug-Free Workplace Act.

---

## Federal Conflict Notes

- **Schedule I federally**: Recreational cannabis remains Schedule I under federal law.
- **Medical rescheduling**: FDA-approved products and state-licensed medical cannabis reclassified to Schedule III effective April 23, 2026.
- **Federal property**: Illegal on federal land and in federal buildings.

---

## Distinctive State Features

1. **Medical-only home grow**: Illinois is one of the few recreational states that does NOT allow recreational home cultivation. Only medical patients may grow.
2. **First state to legalize via legislature**: Illinois was the first state to legalize recreational cannabis through legislative action rather than ballot initiative.
3. **Social equity program**: Strong social equity licensing requirements, though implementation has faced challenges.
4. **Variable tax rate**: Tax rate depends on THC content (10% for <35% THC, 25% for >35% THC, 20% for infused products).

---

## Cross-State Comparison Table

| Feature | Illinois | National Average |
|---------|----------|------------------|
| Recreational legal | Yes | ~24 states |
| Medical legal | Yes | ~38 states |
| Home cultivation | Medical only | ~20 states (most allow recreational) |
| Social equity program | Yes | ~15 states |
| Employment protections | Limited | ~10 states |
| Legislature-legalized | Yes (first state) | ~5 states |

---

## Recording Consent Rules

Illinois is a **two-party consent** state for audio recordings. 720 ILCS 5/14-2 makes it a felony to record a private conversation without the consent of all parties.

---

## Practical Notes

- Recreational users CANNOT grow their own cannabis in Illinois - this is medical-only.
- Non-residents have HALF the possession limits of Illinois residents.
- Keep cannabis in original packaging when transporting.
- Do not consume in public or in vehicles.
- Social equity dispensaries are prioritized in licensing.

---

## Related Entries

- [marijuana-laws-mi.md](marijuana-laws-mi.md) - Michigan (neighbor, recreational with home grow)
- [marijuana-laws-in.md](marijuana-laws-in.md) - Indiana (neighbor, illegal)
- [marijuana-laws-wi.md](marijuana-laws-wi.md) - Wisconsin (neighbor, illegal)
- [tenant-rights-il.md](tenant-rights-il.md) - Illinois Tenant Rights

---

*Review date: 2026-08-26. This entry reflects statutes current as of that date. Always verify with current official sources before relying on this information.*
