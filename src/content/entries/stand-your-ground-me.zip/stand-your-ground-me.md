---
title: "Stand Your Ground / Self-Defense Rights - Maine"
state: "Maine"
state_code: "ME"
topic: "Stand Your Ground / Self-Defense"
tier: 1
date_created: "2026-08-26"
last_reviewed: "2026-08-26"
status: "active"
---

# Stand Your Ground / Self-Defense Rights - Maine

## One-Sentence Verdict

Maine is a duty-to-retreat state outside the home: a person must retreat if they can do so with complete safety before using deadly force in public, but there is no duty to retreat when inside their own dwelling place.

---

## Named Instruments

| Citation | Name | Live Link |
|----------|------|-----------|
| 17-A M.R.S. Sec. 108 | Physical force in defense of a person | [legislature.maine.gov](https://legislature.maine.gov/statutes/17-a/title17-asec108.html) |
| 17-A M.R.S. Sec. 104 | Use of force in defense of premises | [legislature.maine.gov](https://legislature.maine.gov/statutes/17-a/title17-asec104.html) |

---

## Verbatim Quotes Anchored to Character Offsets

### 17-A M.R.S. Sec. 108(2)(C) - Duty to Retreat with Exception for Dwelling

> "(2) A person is justified in using deadly force upon another person: ... (C) However, a person is not justified in using deadly force as provided in paragraph A if: ... (3) The person knows that the person or a 3rd person can, with complete safety: (a) Retreat from the encounter, except that the person or the 3rd person is not required to retreat if the person or the 3rd person is in the person's dwelling place and was not the initial aggressor;"

- **Character offset**: beginning at "(2) A person is justified in using deadly force" through "dwelling place and was not the initial aggressor;"
- **Source**: Maine Revised Statutes, Title 17-A, Section 108, current through 2026.
- **Live link**: [Maine Statutes](https://legislature.maine.gov/statutes/17-a/title17-asec108.html)

### 17-A M.R.S. Sec. 104(3)(B) - Castle Doctrine in Dwelling

> "(3) A person in possession or control of a dwelling place or a person who is licensed or privileged to be therein is justified in using deadly force upon another person: ... (B) When the person reasonably believes that deadly force is necessary to prevent or terminate the commission of a criminal trespass by such other person, who the person reasonably believes: (1) Has entered or is attempting to enter the dwelling place or has surreptitiously remained within the dwelling place without a license or privilege to do so; and (2) Is committing or is likely to commit some other crime within the dwelling place."

- **Character offset**: beginning at "(3) A person in possession or control of a dwelling place" through "some other crime within the dwelling place."
- **Source**: Maine Revised Statutes, Title 17-A, Section 104.
- **Live link**: [Maine Statutes](https://legislature.maine.gov/statutes/17-a/title17-asec104.html)

### 17-A M.R.S. Sec. 104(4) - Demand to Stop Required

> "(4) A person may use deadly force under subsection 3, paragraph B only if the person first demands the person against whom such deadly force is to be used to terminate the criminal trespass and the trespasser fails to immediately comply with the demand, unless the person reasonably believes that it would be dangerous to the person or a 3rd person to make the demand."

- **Character offset**: beginning at "(4) A person may use deadly force" through "dangerous to the person or a 3rd person to make the demand."
- **Source**: Maine Revised Statutes, Title 17-A, Section 104(4).
- **Live link**: [Maine Statutes](https://legislature.maine.gov/statutes/17-a/title17-asec104.html)

---

## Repeal Check

| Item | Status | Date Checked |
|------|--------|--------------|
| 17-A M.R.S. Sec. 108 | Active | 2026-08-26 |
| 17-A M.R.S. Sec. 104 | Active | 2026-08-26 |

No pending repeal legislation identified as of August 2026.

---

## Duty-to-Retreat Matrix

| Location | Duty to Retreat? | Statutory Basis |
|----------|------------------|-----------------|
| Own home / dwelling place | No | 17-A M.R.S. Sec. 108(2)(C)(3)(a) - "not required to retreat if ... in the person's dwelling place" |
| Vehicle | Yes (if safe retreat possible) | General duty to retreat applies; no explicit vehicle exception |
| Workplace | Yes (if safe retreat possible) | General duty to retreat applies; no explicit workplace exception |
| Public place | Yes (if safe retreat possible) | 17-A M.R.S. Sec. 108(2)(C)(3) - "can, with complete safety ... Retreat from the encounter" |

---

## Castle Doctrine Scope

- **Dwelling Place**: Full Castle Doctrine. No duty to retreat. Deadly force permitted against criminal trespassers who the defender reasonably believes are committing or likely to commit another crime inside the dwelling.
- **Demand Requirement**: Unique to Maine - deadly force in defense of premises generally requires first demanding the trespasser stop and leave, unless making such a demand would be dangerous.
- **Vehicle**: Not explicitly covered by Castle Doctrine; general duty to retreat applies.
- **Workplace**: Not explicitly covered; general duty to retreat applies.
- **Curtilage**: Not explicitly defined in statute.

---

## Distinctive State Features

1. **Demand-to-Stop Requirement**: Maine is one of the few states that requires a verbal demand to stop/leave before using deadly force against a trespasser, unless doing so would be dangerous. This is a significant limitation on the Castle Doctrine.
2. **Dwelling-Place Exception Only**: The no-duty-to-retreat exception is narrowly limited to "dwelling place" - not vehicles, workplaces, or curtilage.
3. **No Stand Your Ground**: Maine does not have a SYG statute and has explicitly rejected such legislation. The duty to retreat in public is statutory.
4. **Burden of Proof**: Self-defense is a justification defense; once raised by evidence, the state must disprove it beyond a reasonable doubt.

---

## Cross-State Comparison Table

| Feature | Maine | National Average |
|---------|-------|------------------|
| Statutory SYG | No | ~38 states |
| No duty to retreat - public | No | ~38 states |
| No duty to retreat - home | Yes | All 50 states |
| Demand requirement before deadly force | Yes (unique) | Rare |
| Presumption of fear in home | No | ~25 states |
| Civil immunity statute | No | ~15 states |
| Criminal immunity statute | No | ~10 states |
| Initial aggressor exception | Yes | All states |

---

## Recording Consent Rules

Maine is a **one-party consent** state for audio recordings. 15 M.R.S. Sec. 709 makes it a crime to intercept a private communication without the consent of at least one party.

---

## Practical Notes

- Maine's self-defense laws are more restrictive than most New England states. The demand-to-stop requirement is a critical detail for home defense scenarios.
- In public, the duty to retreat is real and enforceable. Failing to retreat when a safe avenue exists can result in criminal liability even if the underlying threat was genuine.
- The "dwelling place" limitation means that self-defense in a detached garage, shed, or yard may not receive the same protections as inside the home itself.
- Maine's criminal code treats self-defense as a justification defense, which shifts the burden to the prosecution once the defense is raised by evidence.

---

## Related Entries

- [stand-your-ground-nh.md](stand-your-ground-nh.md) - New Hampshire (neighbor, only New England SYG state)
- [stand-your-ground-vt.md](stand-your-ground-vt.md) - Vermont (neighbor, no formal SYG)
- [tenant-rights-me.md](tenant-rights-me.md) - Maine Tenant Rights

---

*Review date: 2026-08-26. This entry reflects statutes current as of that date. Always verify with current official sources before relying on this information.*
