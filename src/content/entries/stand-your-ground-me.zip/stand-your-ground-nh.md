---
title: "Stand Your Ground / Self-Defense Rights - New Hampshire"
state: "New Hampshire"
state_code: "NH"
topic: "Stand Your Ground / Self-Defense"
tier: 1
date_created: "2026-08-26"
last_reviewed: "2026-08-26"
status: "active"
---

# Stand Your Ground / Self-Defense Rights - New Hampshire

## One-Sentence Verdict

New Hampshire is a statutory stand-your-ground state and the only New England state with full SYG protections: a person has no duty to retreat before using deadly force if they are in their dwelling, its curtilage, or anywhere else they have a legal right to be, provided they were not the initial aggressor.

---

## Named Instruments

| Citation | Name | Live Link |
|----------|------|-----------|
| RSA 627:4 | Physical Force in Defense of a Person | [gencourt.state.nh.us](https://gencourt.state.nh.us/rsa/html/NHTOC/NHTOC-627.htm) |
| RSA 627:7 | Use of Force in Defense of Premises | [gencourt.state.nh.us](https://gencourt.state.nh.us/rsa/html/NHTOC/NHTOC-627.htm) |

---

## Verbatim Quotes Anchored to Character Offsets

### RSA 627:4(III)(a) - No Duty to Retreat

> "III. A person is not justified in using deadly force on another to defend himself or herself or a third person from deadly force by the other if he or she knows that he or she and the third person can, with complete safety: (a) Retreat from the encounter, except that he or she is not required to retreat if he or she is within his or her dwelling, its curtilage, or anywhere he or she has a right to be, and was not the initial aggressor; or"

- **Character offset**: beginning at "III. A person is not justified in using deadly force" through "and was not the initial aggressor; or"
- **Source**: New Hampshire Revised Statutes Annotated, Chapter 627, Section 627:4(III)(a), current through 2026.
- **Live link**: [NH RSA](https://gencourt.state.nh.us/rsa/html/NHTOC/NHTOC-627.htm)
- **Note**: The SYG language ("or anywhere he or she has a right to be") was added by 2011, 268:1, effective November 13, 2011.

### RSA 627:4(II)(d) - Castle Doctrine / Deadly Force in Dwelling

> "(d) Is likely to use any unlawful force in the commission of a felony against the actor within such actor's dwelling or its curtilage."

- **Character offset**: beginning at "(d) Is likely to use any unlawful force" through "dwelling or its curtilage."
- **Source**: New Hampshire Revised Statutes Annotated, RSA 627:4(II)(d).
- **Live link**: [NH RSA](https://gencourt.state.nh.us/rsa/html/NHTOC/NHTOC-627.htm)

### RSA 627:4(II-a) - Display of Firearm as Warning

> "II-a. A person who responds to a threat which would be considered by a reasonable person as likely to cause serious bodily injury or death to the person or to another by displaying a firearm or other means of self-defense with the intent to warn away the person making the threat shall not have committed a criminal act."

- **Character offset**: beginning at "II-a. A person who responds to a threat" through "shall not have committed a criminal act."
- **Source**: New Hampshire Revised Statutes Annotated, RSA 627:4(II-a), added 2010, 361:1.
- **Live link**: [NH RSA](https://gencourt.state.nh.us/rsa/html/NHTOC/NHTOC-627.htm)

---

## Repeal Check

| Item | Status | Date Checked |
|------|--------|--------------|
| RSA 627:4 | Active | 2026-08-26 |
| RSA 627:7 | Active | 2026-08-26 |

No pending repeal legislation identified as of August 2026.

---

## Duty-to-Retreat Matrix

| Location | Duty to Retreat? | Statutory Basis |
|----------|------------------|-----------------|
| Own home / dwelling | No | RSA 627:4(III)(a) - "not required to retreat if ... within his or her dwelling" |
| Curtilage | No | RSA 627:4(III)(a) - "its curtilage" |
| Vehicle | No | RSA 627:4(III)(a) - "anywhere he or she has a right to be" |
| Workplace | No | RSA 627:4(III)(a) - "anywhere he or she has a right to be" |
| Public place (lawfully present) | No | RSA 627:4(III)(a) - "anywhere he or she has a right to be" |

---

## Castle Doctrine Scope

- **Dwelling**: Full Castle Doctrine. Deadly force justified against burglary or felony commission within the dwelling or curtilage.
- **Curtilage**: Explicitly included in statute under RSA 627:4(II)(d) and (III)(a).
- **Vehicle**: Covered under general SYG provision ("anywhere he or she has a right to be").
- **Workplace**: Covered under general SYG provision.
- **Display of Firearm**: Unique provision (II-a) protects displaying a firearm as a warning without criminal liability.

---

## Distinctive State Features

1. **Only New England SYG State**: New Hampshire is the only state in New England with a statutory stand-your-ground law. All other New England states (Maine, Vermont, Massachusetts, Rhode Island, Connecticut) impose a duty to retreat in public.
2. **Firearm Warning Display Protected**: RSA 627:4(II-a) explicitly protects displaying a firearm or other self-defense tool as a warning - a rare statutory protection.
3. **Curtilage Explicitly Included**: The statute explicitly mentions "curtilage" alongside dwelling, providing clearer protection for the immediate grounds around a home.
4. **Enacted 2011**: New Hampshire's SYG expansion passed in 2011, replacing a more limited castle doctrine law.

---

## Cross-State Comparison Table

| Feature | New Hampshire | National Average |
|---------|---------------|------------------|
| Statutory SYG | Yes | ~38 states |
| No duty to retreat - public | Yes | ~38 states |
| No duty to retreat - home | Yes | All 50 states |
| Curtilage explicitly included | Yes | ~15 states |
| Firearm warning display protected | Yes (unique) | Rare |
| Presumption of fear in home | No explicit presumption | ~25 states |
| Civil immunity statute | No | ~15 states |
| Criminal immunity statute | No | ~10 states |
| Initial aggressor exception | Yes | All states |

---

## Recording Consent Rules

New Hampshire is a **two-party consent** state for audio recordings. RSA 570-A:2 makes it a felony to record a private communication without the consent of all parties.

---

## Practical Notes

- New Hampshire's SYG law is a significant outlier in New England. Residents of neighboring states should not assume the same protections apply when crossing state lines.
- The firearm warning display provision (II-a) provides important protection for de-escalation tactics, but the display must be in response to a threat that a "reasonable person" would consider likely to cause serious bodily injury or death.
- Despite SYG protections, the "reasonable belief" and "necessary" standards still apply. SYG does not authorize preemptive or retaliatory force.
- New Hampshire has relatively permissive gun laws (constitutional carry since 2017), making SYG knowledge particularly important.

---

## Related Entries

- [stand-your-ground-me.md](stand-your-ground-me.md) - Maine (neighbor, duty to retreat)
- [stand-your-ground-vt.md](stand-your-ground-vt.md) - Vermont (neighbor, no formal SYG)
- [stand-your-ground-ma.md](stand-your-ground-ma.md) - Massachusetts (neighbor, duty to retreat)
- [tenant-rights-nh.md](tenant-rights-nh.md) - New Hampshire Tenant Rights

---

*Review date: 2026-08-26. This entry reflects statutes current as of that date. Always verify with current official sources before relying on this information.*
