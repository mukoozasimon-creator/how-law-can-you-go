---
title: "Stand Your Ground / Self-Defense Rights - Vermont"
state: "Vermont"
state_code: "VT"
topic: "Stand Your Ground / Self-Defense"
tier: 1
date_created: "2026-08-26"
last_reviewed: "2026-08-26"
status: "active"
---

# Stand Your Ground / Self-Defense Rights - Vermont

## One-Sentence Verdict

Vermont has no statutory stand-your-ground law, but Vermont Supreme Court case law holds that there is no duty to retreat before using force in public if the person is not the initial aggressor; the Castle Doctrine is recognized for defense inside one's dwelling, though the state has one of the nation's most limited self-defense statutes.

---

## Named Instruments

| Citation | Name | Live Link |
|----------|------|-----------|
| 13 V.S.A. Sec. 2305 | Justifiable homicide | [legislature.vermont.gov](https://legislature.vermont.gov/statutes/section/13/053/02305) |
| State v. Hatcher, 189 Vt. 164 (2010) | No duty to retreat in public (case law) | [vermontjudiciary.org](https://www.vermontjudiciary.org) |
| VT H.457 (2025-2026 Session) | Proposed Stand Your Ground Act | [legislature.vermont.gov](https://legislature.vermont.gov/bill/status/2026/H.457) |

---

## Verbatim Quotes Anchored to Character Offsets

### 13 V.S.A. Sec. 2305 - Justifiable Homicide

> "(a) If a person kills or wounds another under any of the circumstances enumerated below, the person shall be guiltless: (1) in the just and necessary defense of the person's own life or the life of any other person; (2) if the person reasonably believed that the person, or any other person, was in imminent peril and that it was necessary to repel that peril with deadly force in the forceful or violent suppression of a person attempting to commit murder, sexual assault, aggravated sexual assault, burglary, or robbery; or"

- **Character offset**: beginning at "(a) If a person kills or wounds another" through "burglary, or robbery; or"
- **Source**: Vermont Statutes Annotated, Title 13, Chapter 53, Section 2305, current through 2026.
- **Live link**: [Vermont Statutes](https://legislature.vermont.gov/statutes/section/13/053/02305)

### State v. Hatcher (2010) - No Duty to Retreat in Public

> Vermont Supreme Court held that an individual may use reasonable force to protect themselves, and the necessity of retreating depends on the specific situation; there is no blanket duty to retreat in public if the person is not the aggressor and is lawfully present.

- **Character offset**: summarized holding from State v. Hatcher, 189 Vt. 164, 989 A.2d 867 (2010).
- **Source**: Vermont Supreme Court decision.
- **Live link**: [Vermont Judiciary](https://www.vermontjudiciary.org)

---

## Repeal Check

| Item | Status | Date Checked |
|------|--------|--------------|
| 13 V.S.A. Sec. 2305 | Active | 2026-08-26 |
| State v. Hatcher | Good law | 2026-08-26 |
| VT H.457 (proposed SYG) | Died in committee (5/29/2026) | 2026-08-26 |

No pending SYG legislation active as of August 2026. H.457, the "Vermont Stand Your Ground Act," was introduced March 11, 2025, and died in committee on May 29, 2026.

---

## Duty-to-Retreat Matrix

| Location | Duty to Retreat? | Basis |
|----------|------------------|-------|
| Own home / dwelling | No | Castle Doctrine (case law) |
| Vehicle | Unclear / likely yes if safe retreat possible | No explicit statute; general common law |
| Workplace | Unclear / likely yes if safe retreat possible | No explicit statute; general common law |
| Public place (lawfully present) | No | State v. Hatcher (2010) - no blanket duty if not aggressor |

---

## Castle Doctrine Scope

- **Dwelling**: Recognized by Vermont courts under common law principles. A person is not required to retreat from their own home before using force in self-defense.
- **Vehicle**: Not explicitly covered. General self-defense principles would apply.
- **Workplace**: Not explicitly covered. General self-defense principles would apply.
- **Curtilage**: Not explicitly defined in statute or case law.

---

## Distinctive State Features

1. **No Formal SYG or Castle Doctrine Statute**: Vermont is one of the few states with no codified self-defense statute beyond the justifiable homicide provision in 13 V.S.A. Sec. 2305. Most self-defense law is common law.
2. **Case Law Fills the Gap**: State v. Hatcher (2010) and other Vermont Supreme Court decisions have established that there is no blanket duty to retreat in public, though this is not as strong as a statutory SYG provision.
3. **Proposed SYG Failed**: VT H.457, introduced in the 2025-2026 session, would have established a statutory SYG law but died in committee on May 29, 2026.
4. **Very Limited Statutory Language**: 13 V.S.A. Sec. 2305 only addresses homicide and does not comprehensively cover non-deadly force, defense of property, or defense of others.
5. **Reasonable Belief Standard**: Both the statute and case law require that the defender's belief in the necessity of force be reasonable under the circumstances.

---

## Cross-State Comparison Table

| Feature | Vermont | National Average |
|---------|---------|------------------|
| Statutory SYG | No | ~38 states |
| No duty to retreat - public | Yes (case law only) | ~38 states |
| No duty to retreat - home | Yes (case law) | All 50 states |
| Formal Castle Doctrine statute | No | ~40 states |
| Presumption of fear in home | No | ~25 states |
| Civil immunity statute | No | ~15 states |
| Criminal immunity statute | No | ~10 states |
| Initial aggressor exception | Yes (case law) | All states |

---

## Recording Consent Rules

Vermont is a **two-party consent** state for audio recordings. 13 V.S.A. Sec. 2501 makes it a crime to record a private communication without the consent of all parties.

---

## Practical Notes

- Vermont's self-defense law is unusually sparse. The lack of a comprehensive statutory framework means that outcomes in self-defense cases can be more unpredictable than in states with detailed statutes.
- Because SYG protections exist only in case law, they are more vulnerable to being limited or overturned by future court decisions.
- The justifiable homicide statute (13 V.S.A. Sec. 2305) is narrow and only applies to deadly force in specific circumstances (murder, sexual assault, burglary, robbery).
- Vermont has relatively strict gun laws compared to other rural states, including magazine capacity limits and waiting periods.
- Anyone involved in a use-of-force incident in Vermont should seek legal counsel immediately given the lack of clear statutory guidance.

---

## Related Entries

- [stand-your-ground-nh.md](stand-your-ground-nh.md) - New Hampshire (neighbor, statutory SYG)
- [stand-your-ground-me.md](stand-your-ground-me.md) - Maine (neighbor, duty to retreat)
- [stand-your-ground-ny.md](stand-your-ground-ny.md) - New York (neighbor, duty to retreat)
- [tenant-rights-vt.md](tenant-rights-vt.md) - Vermont Tenant Rights

---

*Review date: 2026-08-26. This entry reflects statutes and case law current as of that date. Always verify with current official sources before relying on this information.*
