---
title: "Marijuana Laws - Arizona"
state: "Arizona"
state_code: "AZ"
topic: "Marijuana Laws"
tier: 1
date_created: "2026-08-26"
last_reviewed: "2026-08-26"
status: "active"
---

# Marijuana Laws - Arizona

## One-Sentence Verdict

Arizona legalized recreational marijuana for adults 21+ in November 2020 via Proposition 207 (Smart and Safe Arizona Act); adults may possess up to 1 oz of flower, 5g of concentrate, and grow up to 6 plants per person (12 per household), with a 16% excise tax and automatic expungement for prior low-level convictions.

---

## Legal Status Summary

| Category | Status | Effective Date |
|----------|--------|----------------|
| Recreational (adult-use) | Legal | November 30, 2020 |
| Medical | Legal | 2010 (Arizona Medical Marijuana Act) |
| Home cultivation | Legal (6 per person, 12 per household) | November 30, 2020 |
| Retail sales | Legal (licensed dispensaries) | January 2021 |
| Automatic expungement | Yes | 2021 |

---

## Named Instruments

| Citation | Name | Live Link |
|----------|------|-----------|
| A.R.S. Sec. 36-2851 et seq. | Smart and Safe Arizona Act (Prop 207) | [azleg.gov](https://azleg.gov) |
| A.R.S. Sec. 36-2801 et seq. | Arizona Medical Marijuana Act | [azleg.gov](https://azleg.gov) |
| A.R.S. Sec. 36-2852 | Personal use; civil penalties | [azleg.gov](https://azleg.gov) |
| A.R.S. Sec. 36-2862 | Expungement | [azleg.gov](https://azleg.gov) |
| I-04-2026 | Proposed repeal initiative (pending signatures) | [azsos.gov](https://azsos.gov) |

---

## Verbatim Quotes Anchored to Character Offsets

### A.R.S. Sec. 36-2852 - Personal Use Limits

> "A person twenty-one years of age or older may do any of the following: 1. Possess, consume, purchase, obtain, process, produce or transport one ounce or less of marijuana, of which not more than five grams may be in the form of marijuana concentrate. 2. Possess, use, process, produce or transport marijuana paraphernalia. 3. Cultivate up to six marijuana plants for personal use at the person's primary residence and no more than twelve marijuana plants at a single residence."

- **Character offset**: beginning at "A person twenty-one years of age or older" through "at a single residence."
- **Source**: Arizona Revised Statutes, Title 36, Chapter 28, Article 14, Section 36-2852, current through 2026.
- **Live link**: [Arizona State Legislature](https://azleg.gov)

### A.R.S. Sec. 36-2862 - Expungement

> "A person who is convicted of any of the following offenses based on conduct occurring before November 30, 2020 may petition the court to have the record of that conviction expunged: 1. Possessing, consuming or transporting two and one-half ounces or less of marijuana, of which not more than twelve and one-half grams was in the form of marijuana concentrate. 2. Possessing, transporting, cultivating or processing not more than six marijuana plants for personal use."

- **Character offset**: beginning at "A person who is convicted of any" through "for personal use."
- **Source**: Arizona Revised Statutes, Section 36-2862.
- **Live link**: [Arizona State Legislature](https://azleg.gov)

---

## Repeal Check

| Item | Status | Date Checked |
|------|--------|--------------|
| Prop 207 / A.R.S. 36-2851 | Active | 2026-08-26 |
| I-04-2026 (proposed repeal) | Pending signatures (255,949 needed by 7/3/2026) | 2026-08-26 |

A proposed ballot initiative (I-04-2026) seeks to end commercial recreational sales while preserving medical access and personal possession/home grow rights. Status uncertain as of August 2026.

---

## Possession Limits

| Product Type | Legal Limit | Over-Limit Penalty |
|--------------|-------------|-------------------|
| Cannabis flower | 1 oz | Civil penalty: $100 |
| Concentrate | 5g (part of 1 oz) | Civil penalty: $100 |
| Plants (home grow) | 6 per person, 12 per household | Class 5 felony |

### Penalty Tiers for Over-Limit Possession

| Amount | Classification | Penalty |
|--------|-----------------|---------|
| 1-2.5 oz | Civil penalty | $100 fine |
| 2.5 oz - 2 lbs | Petty offense | Varies |
| Over 2 lbs | Felony | Enhanced penalties |

---

## Home Cultivation Rules

- **Limit**: 6 plants per person; 12 plants maximum per household.
- **Location**: Primary residence only.
- **Security**: Must be in a locked, enclosed area not visible from public view.
- **Medical patients**: May grow up to 12 plants if no dispensary operates within 25 miles. Must be in an enclosed, locked facility.
- **Sales**: Home-grown cannabis is for personal use only; cannot be sold.
- **Gifting**: Adults may gift up to 1 oz to another adult 21+.
- **Concentrate manufacturing**: Making concentrates at home is prohibited.

---

## Purchase and Retail

- **Age**: 21+ for recreational; 18+ with medical card.
- **Licensed retailers**: Arizona Department of Health Services (ADHS) licenses required.
- **Taxes**: 16% excise tax + standard transaction privilege tax.
- **Medical exemption**: Medical cannabis purchases are exempt from the 16% excise tax.
- **Delivery**: Available through licensed retailers.
- **Out-of-state purchases**: Out-of-state residents 21+ may purchase recreational cannabis.

---

## Consumption Rules

- **Private property**: Legal.
- **Public spaces**: Illegal.
- **Vehicles**: Illegal to consume or possess open container while driving.
- **Workplaces**: Employers may prohibit cannabis use and maintain drug-free workplace policies.

---

## DUI / Impairment

- **Standard**: It is illegal to drive while impaired by marijuana to the slightest degree (A.R.S. Sec. 28-1381(A)).
- **Per se limit**: No specific THC blood concentration limit.
- **Penalties**: First offense - minimum 10 days jail, $1,250 fine, license suspension 90 days-1 year, ignition interlock.

---

## Employment Protections

- **Limited protection**: Some 2023 amendments added narrow off-duty protections, but safety-sensitive positions remain fully subject to drug-free workplace rules.
- **Employers**: May drug test and terminate for positive results even for off-duty legal use.
- **Federal employees/contractors**: Fully subject to federal marijuana prohibitions.

---

## Federal Conflict Notes

- **Schedule I federally**: Recreational cannabis remains Schedule I under federal law.
- **Federal property**: Illegal on federal land, including national parks and military bases.

---

## Distinctive State Features

1. **Automatic expungement**: Prop 207 included automatic expungement for prior low-level marijuana convictions - roughly 250,000 convictions became eligible.
2. **Medical proximity rule**: Medical patients may only grow if no dispensary operates within 25 miles of their home.
3. **Proposed repeal (2026)**: I-04-2026 seeks to end commercial recreational sales while preserving medical and personal use rights.
4. **Ryan's Law (2026)**: HB 2081 requires healthcare facilities to allow terminally ill patients to use medical cannabis for palliative care.
5. **Out-of-state purchases allowed**: Arizona permits out-of-state residents to purchase recreational cannabis.

---

## Cross-State Comparison Table

| Feature | Arizona | National Average |
|---------|---------|------------------|
| Recreational legal | Yes | ~24 states |
| Medical legal | Yes | ~38 states |
| Home cultivation | Yes (6/12) | ~20 states |
| Automatic expungement | Yes | ~12 states |
| Out-of-state purchases | Yes | ~15 states |
| Employment protections | Limited | ~10 states |

---

## Recording Consent Rules

Arizona is a **one-party consent** state for audio recordings. A.R.S. Sec. 13-3005 makes it a felony to record a private communication without the consent of at least one party.

---

## Practical Notes

- Keep cannabis in original packaging when transporting.
- Do not consume in public or in vehicles.
- Medical patients who want to grow must verify no dispensary is within 25 miles.
- Prior low-level convictions may be eligible for expungement under Prop 207.
- Employers can still test and terminate for cannabis use, even if legal.

---

## Related Entries

- [marijuana-laws-nm.md](marijuana-laws-nm.md) - New Mexico (neighbor, recreational)
- [marijuana-laws-ca.md](marijuana-laws-ca.md) - California (neighbor, recreational)
- [marijuana-laws-nv.md](marijuana-laws-nv.md) - Nevada (neighbor, recreational)
- [tenant-rights-az.md](tenant-rights-az.md) - Arizona Tenant Rights

---

*Review date: 2026-08-26. This entry reflects statutes current as of that date. Always verify with current official sources before relying on this information.*
