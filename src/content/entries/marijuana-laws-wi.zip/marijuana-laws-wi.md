---
title: "Marijuana Laws - Wisconsin"
state: "Wisconsin"
state_code: "WI"
topic: "Marijuana Laws"
tier: 1
date_created: "2026-08-26"
last_reviewed: "2026-08-26"
status: "active"
---

# Marijuana Laws - Wisconsin

## One-Sentence Verdict

Recreational marijuana remains fully illegal in Wisconsin; possession of any amount is a misdemeanor on first offense and a felony on second offense, while the only legal cannabis is CBD oil with a physician's certification, and no comprehensive medical marijuana program exists.

---

## Legal Status Summary

| Category | Status | Effective Date |
|----------|--------|----------------|
| Recreational (adult-use) | Illegal | N/A |
| Medical | Limited (CBD oil only) | 2014 (Lydia's Law / AB 726) |
| Home cultivation | Illegal | N/A |
| Retail sales | Illegal | N/A |
| Decriminalization | Partial (some municipalities) | Varies |

---

## Named Instruments

| Citation | Name | Live Link |
|----------|------|-----------|
| Wis. Stat. Sec. 961.41(3g)(e) | Possession of marijuana | [docs.legis.wisconsin.gov](https://docs.legis.wisconsin.gov) |
| Wis. Stat. Sec. 961.41(3g)(d) | Second or subsequent offense | [docs.legis.wisconsin.gov](https://docs.legis.wisconsin.gov) |
| Wis. Stat. Sec. 961.41(1m)(h) | Manufacture/delivery | [docs.legis.wisconsin.gov](https://docs.legis.wisconsin.gov) |
| 2013 Act 267 (Lydia's Law) | CBD oil exemption | [docs.legis.wisconsin.gov](https://docs.legis.wisconsin.gov) |
| AB 130 (2025-2026) | Proposed medical cannabis bill | [docs.legis.wisconsin.gov](https://docs.legis.wisconsin.gov) |

---

## Verbatim Quotes Anchored to Character Offsets

### Wis. Stat. Sec. 961.41(3g)(e) - First Offense Possession

> "If a person possesses or attempts to possess a controlled substance or a controlled substance analog, the person is guilty of a Class A misdemeanor."

- **Character offset**: beginning at "If a person possesses or attempts to possess" through "a Class A misdemeanor."
- **Source**: Wisconsin Statutes, Chapter 961, Section 961.41(3g)(e), current through 2026.
- **Live link**: [Wisconsin State Legislature](https://docs.legis.wisconsin.gov)

### Wis. Stat. Sec. 961.41(3g)(d) - Second Offense

> "If a person possesses or attempts to possess a controlled substance or a controlled substance analog and the person has one or more previous convictions for possessing or attempting to possess a controlled substance or a controlled substance analog, the person is guilty of a Class I felony."

- **Character offset**: beginning at "If a person possesses or attempts to possess" through "a Class I felony."
- **Source**: Wisconsin Statutes, Section 961.41(3g)(d).
- **Live link**: [Wisconsin State Legislature](https://docs.leg.wisconsin.gov)

---

## Repeal Check

| Item | Status | Date Checked |
|------|--------|--------------|
| Wis. Stat. Sec. 961.41(3g) | Active | 2026-08-26 |
| Lydia's Law | Active | 2026-08-26 |
| AB 130 (medical) | Pending (not advanced) | 2026-08-26 |

No active legalization bill as of August 2026. Governor Evers has included legalization in his budget proposals, but the legislature has rejected it.

---

## Possession Penalties

| Offense | Classification | Penalty |
|---------|-----------------|---------|
| First offense (any amount) | Class A Misdemeanor | Up to 9 months jail, $10,000 fine |
| Second or subsequent offense | Class I Felony | Up to 3.5 years prison, $10,000 fine |

### Sale/Cultivation

| Amount | Classification | Penalty |
|--------|-----------------|---------|
| 200g or less | Class I Felony | Up to 3.5 years prison, $10,000 fine |
| 200g - 1,000g | Class H Felony | Up to 6 years prison, $10,000 fine |
| 1,000g - 2,500g | Class G Felony | Up to 10 years prison, $25,000 fine |
| 2,500g - 10,000g | Class F Felony | Up to 12.5 years prison, $25,000 fine |
| 10,000g+ | Class E Felony | Up to 15 years prison, $50,000 fine |

---

## Medical Program

- **Status**: NO comprehensive medical marijuana program exists in Wisconsin.
- **Lydia's Law (2014)**: Allows possession of CBD oil with a physician's certification for seizure disorders. This is NOT a true medical cannabis program.
- **No dispensaries**: There are no licensed medical cannabis dispensaries in Wisconsin.
- **No home cultivation**: Patients cannot grow their own medicine.
- **No reciprocity**: Out-of-state medical cards are NOT recognized.

---

## Hemp and CBD

- **Hemp-derived CBD**: Legal under federal Farm Bill; must contain 0.3% or less Delta-9 THC.
- **Delta-8, Delta-10**: In legal gray area; no explicit state ban as of August 2026.
- **Hemp vapes**: No explicit state ban.

---

## Local Decriminalization

- **Madison**: City ordinance decriminalizes possession of up to 28g in private residences.
- **Milwaukee**: Civil fine of $1 for possession of 25g or less.
- **Other municipalities**: Some have enacted civil penalties for small amounts.
- **Important**: Local ordinances do NOT override state law. State police and other state law enforcement can still arrest under state statute.

---

## DUI / Impairment

- **Standard**: It is illegal to operate a motor vehicle while under the influence of any drug (Wis. Stat. Sec. 346.63).
- **Per se limit**: No specific THC blood limit.
- **Penalties**: First offense - up to 6 months jail, $150-$300 fine, license suspension 6-9 months.

---

## Employment Protections

- **No statutory protection**: Wisconsin does not protect off-duty cannabis use.
- **At-will employment**: Employers may terminate for cannabis use.
- **Federal contractors**: Subject to federal Drug-Free Workplace Act.

---

## Federal Conflict Notes

- **Schedule I federally**: All marijuana remains Schedule I under federal law.
- **Federal property**: Illegal on federal land and in federal buildings.
- **Federal housing**: Public housing may prohibit cannabis use.

---

## Distinctive State Features

1. **Second offense = felony**: Wisconsin is one of the few states where a second possession offense is a felony, even for small amounts.
2. **No medical program**: Wisconsin has no comprehensive medical cannabis program.
3. **Surrounded by legal states**: Wisconsin is bordered by Illinois and Michigan - both recreational-legal states.
4. **Governor supports legalization**: Governor Evers has repeatedly included legalization in his budget proposals, but the Republican-controlled legislature has rejected it.

---

## Cross-State Comparison Table

| Feature | Wisconsin | National Average |
|---------|-----------|------------------|
| Recreational legal | No | ~24 states |
| Medical legal | No (CBD only) | ~38 states |
| Home cultivation | No | ~20 states |
| Second offense penalty | Felony | Rare |
| Employment protections | No | ~10 states |

---

## Recording Consent Rules

Wisconsin is a **one-party consent** state for audio recordings. Wis. Stat. Sec. 968.31 makes it a crime to record a private communication without the consent of at least one party.

---

## Practical Notes

- Even a single joint can result in arrest and jail time in Wisconsin.
- A second possession offense is a felony - this is unusually harsh.
- Do not bring cannabis from Illinois or Michigan into Wisconsin - this is a serious crime.
- If you have a medical card from another state, it is NOT recognized in Wisconsin.
- The only legal cannabis product is CBD oil with a physician's certification for seizure disorders.

---

## Related Entries

- [marijuana-laws-il.md](marijuana-laws-il.md) - Illinois (neighbor, recreational)
- [marijuana-laws-mi.md](marijuana-laws-mi.md) - Michigan (neighbor, recreational)
- [marijuana-laws-mn.md](marijuana-laws-mn.md) - Minnesota (neighbor, recreational)
- [marijuana-laws-ia.md](marijuana-laws-ia.md) - Iowa (neighbor, medical only)
- [tenant-rights-wi.md](tenant-rights-wi.md) - Wisconsin Tenant Rights

---

*Review date: 2026-08-26. This entry reflects statutes current as of that date. Always verify with current official sources before relying on this information.*
