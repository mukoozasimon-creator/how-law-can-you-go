---
title: "Marijuana Laws - Tennessee"
state: "Tennessee"
state_code: "TN"
topic: "Marijuana Laws"
tier: 1
date_created: "2026-08-26"
last_reviewed: "2026-08-26"
status: "active"
---

# Marijuana Laws - Tennessee

## One-Sentence Verdict

Recreational marijuana remains fully illegal in Tennessee; possession of 0.5 oz or less is a misdemeanor punishable by up to 1 year in jail and a $2,500 fine, while the only legal cannabis is low-THC CBD oil for patients with intractable seizures, and no comprehensive medical marijuana program exists.

---

## Legal Status Summary

| Category | Status | Effective Date |
|----------|--------|----------------|
| Recreational (adult-use) | Illegal | N/A |
| Medical | Limited (CBD oil for epilepsy only) | 2014 |
| Home cultivation | Illegal | N/A |
| Retail sales | Illegal | N/A |
| Decriminalization | Partial (0.5 oz or less = misdemeanor) | Ongoing |

---

## Named Instruments

| Citation | Name | Live Link |
|----------|------|-----------|
| Tenn. Code Ann. Sec. 39-17-417 | Simple possession or casual exchange | [publications.tnsosfiles.com](https://publications.tnsosfiles.com) |
| Tenn. Code Ann. Sec. 39-17-415 | Manufacture, delivery, sale | [publications.tnsosfiles.com](https://publications.tnsosfiles.com) |
| Tenn. Code Ann. Sec. 39-17-452 | Cannabis oil | [publications.tnsosfiles.com](https://publications.tnsosfiles.com) |
| HB 1634 (2026) | Proposed medical cannabis bill | [capitol.tn.gov](https://capitol.tn.gov) |

---

## Verbatim Quotes Anchored to Character Offsets

### Tenn. Code Ann. Sec. 39-17-417 - Simple Possession

> "It is an offense for a person to knowingly possess or casually exchange a controlled substance, unless the substance was obtained directly from, or pursuant to, a valid prescription or order of a practitioner while acting in the course of professional practice."

- **Character offset**: beginning at "It is an offense for a person" through "course of professional practice."
- **Source**: Tennessee Code Annotated, Title 39, Chapter 17, Part 4, Section 39-17-417, current through 2026.
- **Live link**: [Tennessee Code](https://publications.tnsosfiles.com)

### Tenn. Code Ann. Sec. 39-17-452 - Cannabis Oil

> "A person may possess cannabis oil if the person has obtained the cannabis oil pursuant to a valid prescription or order of a practitioner while acting in the course of professional practice."

- **Character offset**: beginning at "A person may possess cannabis oil" through "course of professional practice."
- **Source**: Tennessee Code Annotated, Section 39-17-452.
- **Live link**: [Tennessee Code](https://publications.tnsosfiles.com)

---

## Repeal Check

| Item | Status | Date Checked |
|------|--------|--------------|
| Tenn. Code Ann. Sec. 39-17-417 | Active | 2026-08-26 |
| Tenn. Code Ann. Sec. 39-17-452 | Active | 2026-08-26 |
| HB 1634 (medical) | Pending (not advanced) | 2026-08-26 |

No active medical or recreational legalization bill as of August 2026. Multiple bills have been introduced but none have passed.

---

## Possession Penalties

| Amount | Classification | Penalty |
|--------|-----------------|---------|
| 0.5 oz or less | Class A Misdemeanor | Up to 1 year jail, $2,500 fine |
| 0.5 oz - 10 lbs | Felony | 1-6 years prison, $5,000 fine |
| 10-70 lbs | Felony | 2-12 years prison, $5,000 fine |
| 70-300 lbs | Felony | 8-30 years prison, $200,000 fine |
| 300+ lbs | Felony | 15-60 years prison, $500,000 fine |

### Concentrates

| Activity | Classification | Penalty |
|----------|-----------------|---------|
| Possession of any amount | Felony | 1-6 years prison, $5,000 fine |

---

## Medical Program

- **Status**: NO comprehensive medical marijuana program exists in Tennessee.
- **2014 Cannabis Oil Law**: Very narrow exception for patients with intractable seizures to possess CBD oil with less than 0.9% THC. This is NOT a true medical cannabis program.
- **HB 1634 (2026)**: Proposed medical cannabis bill that would create a limited medical program. As of August 2026, it has not passed.
- **No dispensaries**: There are no licensed medical cannabis dispensaries in Tennessee.
- **No home cultivation**: Patients cannot grow their own medicine.
- **No reciprocity**: Out-of-state medical cards are NOT recognized.

---

## Hemp and CBD

- **Hemp-derived CBD**: Legal under federal Farm Bill; must contain 0.3% or less Delta-9 THC.
- **Delta-8, Delta-10**: In legal gray area; no explicit state ban as of August 2026.
- **Hemp vapes**: No explicit state ban.

---

## DUI / Impairment

- **Standard**: It is illegal to operate a motor vehicle while under the influence of any drug (Tenn. Code Ann. Sec. 55-10-401).
- **Per se limit**: No specific THC blood limit.
- **Penalties**: First offense - up to 11 months 29 days jail, $350-$1,500 fine, license suspension 1 year.

---

## Employment Protections

- **No statutory protection**: Tennessee does not protect off-duty cannabis use.
- **At-will employment**: Employers may terminate for cannabis use.
- **Federal contractors**: Subject to federal Drug-Free Workplace Act.

---

## Federal Conflict Notes

- **Schedule I federally**: All marijuana remains Schedule I under federal law.
- **Federal property**: Illegal on federal land, including national parks (Great Smoky Mountains).
- **Federal housing**: Public housing may prohibit cannabis use.

---

## Distinctive State Features

1. **One of ~10 states with no medical program**: Tennessee has no comprehensive medical cannabis program, only a narrow CBD oil exception for epilepsy.
2. **Harsh penalties for concentrates**: Any amount of concentrate is a felony.
3. **No decriminalization**: Even 0.5 oz or less is a Class A misdemeanor with up to 1 year in jail.
4. **Legislative gridlock**: Multiple medical cannabis bills have been introduced but consistently blocked in committee.

---

## Cross-State Comparison Table

| Feature | Tennessee | National Average |
|---------|-----------|------------------|
| Recreational legal | No | ~24 states |
| Medical legal | No (CBD oil only) | ~38 states |
| Home cultivation | No | ~20 states |
| Concentrate penalties | Felony at any amount | Varies |
| Employment protections | No | ~10 states |

---

## Recording Consent Rules

Tennessee is a **one-party consent** state for audio recordings. Tenn. Code Ann. Sec. 39-13-601 makes it a crime to record a private communication without the consent of at least one party.

---

## Practical Notes

- Even small amounts of marijuana can result in jail time in Tennessee.
- Vape pens and edibles are felonies at ANY amount.
- If you have a medical card from another state, it is NOT recognized in Tennessee.
- The only legal cannabis product is CBD oil with less than 0.9% THC for intractable seizures.
- Great Smoky Mountains National Park is federal property - cannabis is illegal there.

---

## Related Entries

- [marijuana-laws-va.md](marijuana-laws-va.md) - Virginia (neighbor, partially legal)
- [marijuana-laws-nc.md](marijuana-laws-nc.md) - North Carolina (neighbor, illegal)
- [marijuana-laws-ga.md](marijuana-laws-ga.md) - Georgia (neighbor, limited medical)
- [marijuana-laws-ky.md](marijuana-laws-ky.md) - Kentucky (neighbor, medical only)
- [tenant-rights-tn.md](tenant-rights-tn.md) - Tennessee Tenant Rights

---

*Review date: 2026-08-26. This entry reflects statutes current as of that date. Always verify with current official sources before relying on this information.*
