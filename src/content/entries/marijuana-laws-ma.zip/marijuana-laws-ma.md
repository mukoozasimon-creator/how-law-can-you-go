---
title: "Marijuana Laws - Massachusetts"
state: "Massachusetts"
state_code: "MA"
topic: "Marijuana Laws"
tier: 1
date_created: "2026-08-26"
last_reviewed: "2026-08-26"
status: "active"
---

# Marijuana Laws - Massachusetts

## One-Sentence Verdict

Massachusetts legalized recreational marijuana for adults 21+ in December 2016 via Question 4; adults may possess up to 1 oz in public, store up to 10 oz at home, cultivate up to 6 plants per person (12 per household), and purchase from licensed dispensaries, with a 10.75% excise tax plus local option tax.

---

## Legal Status Summary

| Category | Status | Effective Date |
|----------|--------|----------------|
| Recreational (adult-use) | Legal | December 15, 2016 |
| Medical | Legal | 2012 (Question 3) |
| Home cultivation | Legal (6 per person, 12 per household) | December 15, 2016 |
| Retail sales | Legal (licensed dispensaries) | November 2018 |
| Social consumption | Legal (licensed consumption establishments) | 2023 |

---

## Named Instruments

| Citation | Name | Live Link |
|----------|------|-----------|
| MGL c. 94G | Regulation of marijuana not medically prescribed | [malegislature.gov](https://malegislature.gov) |
| MGL c. 94G, Sec. 7 | Personal use of marijuana | [malegislature.gov](https://malegislature.gov) |
| MGL c. 94G, Sec. 2 | Limitations | [malegislature.gov](https://malegislature.gov) |
| MGL c. 94C, Sec. 32L | Possession of 3 oz or less | [malegislature.gov](https://malegislature.gov) |
| St. 2026, c. 65 | Act modernizing Commonwealth's cannabis laws | [malegislature.gov](https://malegislature.gov) |

---

## Verbatim Quotes Anchored to Character Offsets

### MGL c. 94G, Sec. 7 - Possession Limits

> "A person twenty-one years of age or older may possess up to one ounce of marijuana outside of the person's residence and up to ten ounces of marijuana inside the person's residence."

- **Character offset**: beginning at "A person twenty-one years of age or older" through "inside the person's residence."
- **Source**: Massachusetts General Laws, Chapter 94G, Section 7, current through 2026.
- **Live link**: [Massachusetts Legislature](https://malegislature.gov)

### MGL c. 94G, Sec. 7 - Home Cultivation

> "A person twenty-one years of age or older may cultivate not more than six marijuana plants for personal use at the person's primary residence. If 2 or more persons twenty-one years of age or older reside at the same residence, the residence may contain not more than 12 marijuana plants."

- **Character offset**: beginning at "A person twenty-one years of age or older" through "not more than 12 marijuana plants."
- **Source**: Massachusetts General Laws, Chapter 94G, Section 7.
- **Live link**: [Massachusetts Legislature](https://malegislature.gov)

---

## Repeal Check

| Item | Status | Date Checked |
|------|--------|--------------|
| MGL c. 94G | Active | 2026-08-26 |
| St. 2026, c. 65 | Active | 2026-08-26 |

No pending repeal legislation identified as of August 2026.

---

## Possession Limits

| Product Type | Public Limit | Home Storage Limit | Over-Limit Penalty |
|--------------|-------------|-------------------|-------------------|
| Cannabis flower | 1 oz | 10 oz | Civil penalty |
| Concentrate | Part of 1 oz equivalent | 10 oz equivalent | Civil penalty |
| Plants (home grow) | 6 per person, 12 per household | N/A | Civil penalty |

### Home Storage Over 1 oz

If you have more than 1 oz stored at home, the excess must be secured by a lock. Violation can result in civil penalty and forfeiture.

---

## Home Cultivation Rules

- **Limit**: 6 plants per person; 12 plants maximum per household.
- **Location**: Primary residence only.
- **Security**: Must be in an area equipped with a lock or security device.
- **Visibility**: Cannot be visible from a public place without binoculars, aircraft, or other optical aids.
- **Concentrate manufacturing**: Cannot manufacture using any liquid or gas with a flashpoint below 100 degrees Fahrenheit (i.e., no butane extraction).
- **Medical patients**: May grow enough to yield a 60-day supply (defined as 10 oz of usable marijuana).
- **Landlords**: May prohibit cultivation in rental properties.

---

## Purchase and Retail

- **Age**: 21+ for recreational; 18+ with medical certification.
- **Licensed retailers**: Cannabis Control Commission (CCC) licenses required.
- **Taxes**: 10.75% state excise tax + up to 3% local option tax + standard sales tax.
- **Medical exemption**: Medical cannabis purchases are exempt from the 10.75% excise tax.
- **Delivery**: Available through licensed retailers.
- **Social consumption**: Licensed on-site consumption establishments are permitted.

---

## Consumption Rules

- **Private property**: Legal with property owner's permission.
- **Public spaces**: Illegal.
- **Vehicles**: Illegal to consume or possess open container while driving.
- **Workplaces**: Employers may prohibit cannabis use and maintain drug-free workplace policies.

---

## DUI / Impairment

- **Standard**: It is illegal to operate a motor vehicle while under the influence of marijuana (MGL c. 90, Sec. 24).
- **Per se limit**: No specific THC blood concentration limit.
- **Penalties**: First offense OUI - up to 2.5 years jail, $500-$5,000 fine, license suspension 1 year.

---

## Employment Protections

- **No comprehensive statutory protection**: Massachusetts does not have broad employment protections for off-duty recreational cannabis use.
- **Medical patients**: Some protections under the medical marijuana law.
- **Federal contractors**: Subject to federal Drug-Free Workplace Act.

---

## Federal Conflict Notes

- **Schedule I federally**: Recreational cannabis remains Schedule I under federal law.
- **Federal property**: Illegal on federal land and in federal buildings.

---

## Distinctive State Features

1. **Social consumption establishments**: Massachusetts permits licensed on-site consumption lounges, unlike many states.
2. **2026 modernization act**: St. 2026, c. 65 modernized the Commonwealth's cannabis laws, though details are still being implemented.
3. **Strong medical program**: Massachusetts has one of the more robust medical programs on the East Coast.
4. **Lock requirement for home storage**: Unique requirement that excess over 1 oz at home must be secured by a lock.

---

## Cross-State Comparison Table

| Feature | Massachusetts | National Average |
|---------|---------------|------------------|
| Recreational legal | Yes | ~24 states |
| Medical legal | Yes | ~38 states |
| Home cultivation | Yes (6/12) | ~20 states |
| Social consumption | Yes | ~8 states |
| Employment protections | Limited | ~10 states |

---

## Recording Consent Rules

Massachusetts is a **two-party consent** state for audio recordings. MGL c. 272, Sec. 99 makes it a felony to record a private communication without the consent of all parties.

---

## Practical Notes

- Keep cannabis in original packaging when transporting.
- Do not consume in public or in vehicles.
- If storing more than 1 oz at home, use a locked container.
- Do not use butane or other volatile solvents for home concentrate extraction.
- Landlords may prohibit cultivation; check your lease.

---

## Related Entries

- [marijuana-laws-ny.md](marijuana-laws-ny.md) - New York (neighbor, recreational)
- [marijuana-laws-ct.md](marijuana-laws-ct.md) - Connecticut (neighbor, recreational)
- [marijuana-laws-vt.md](marijuana-laws-vt.md) - Vermont (neighbor, recreational)
- [marijuana-laws-ri.md](marijuana-laws-ri.md) - Rhode Island (neighbor, recreational)
- [tenant-rights-ma.md](tenant-rights-ma.md) - Massachusetts Tenant Rights

---

*Review date: 2026-08-26. This entry reflects statutes current as of that date. Always verify with current official sources before relying on this information.*
